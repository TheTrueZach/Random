﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AssetBoxCreator
//{
//    internal class Folders
//    {
//        public ArrayList arlist = new ArrayList();
//        public ArrayList arlistFiles = new ArrayList();

//        public Folders(string currentfilepath)
//        {
//            //arlist.Add(currentfilepath);
//            if (currentfilepath != null && currentfilepath != "")
//            {
//                arlist.Add(currentfilepath);
//                loop(currentfilepath);
//                AllFiles();
//            }
//        }

//        private void loop(string start)
//        {
//            if (start != null && start != "")
//            {
//                string[] dirs = Directory.GetDirectories(start);
//                foreach (string dir in dirs)
//                {
//                    if (Directory.GetDirectories(dir).Length != 0)
//                    {
//                        loop(dir);
//                    }
//                    arlist.Add(dir);
//                }
//            }
//        }

//        private void AllFiles()
//        {
//            foreach (string item in arlist)
//            {
//                string[] dirs = Directory.GetDirectories(item);
//                foreach (var item1 in dirs)
//                {
//                    arlistFiles.Add(item1);
//                }
//            }
//        }
//    }    
//}
