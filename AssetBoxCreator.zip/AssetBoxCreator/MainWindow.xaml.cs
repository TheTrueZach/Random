﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AssetBoxCreator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<string> listbox = new List<string>();
        public List<string> listboxTemp = new List<string>();
        public string currentDirectory = "G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering";
        private string orignalPath = "G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering";
        private int z = 0;
        private int y = 0;
        private string item;
        private List<string[]> strings = new List<string[]>();
        public MainWindow()
        {
            InitializeComponent();
            RefreshListBox(currentDirectory);
        }

        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (Explore.Content.ToString() == "Switch to Explore")
            {
                if (e.Key == Key.Return)
                {
                    string toBeParsed = Input.Text;
                    toBeParsed = toBeParsed.Trim();
                    string[] temp = toBeParsed.Split(',');
                    if (temp.Length != 3)
                    {
                        //Output.Text = "Failed by Wrong Formatting The correct Format is \"Number,Name,RevNumber\" ex. \"32400370,ModUSB,001\".";
                    }
                    else if (temp.Length == 3)
                    {
                        string assetNumber = temp[0];
                        string assetName = temp[1];
                        //string assetRev = temp[2];
                        int assetRev = int.Parse(temp[2]);
                        string temp1 = Directory.CreateDirectory("G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering\\" + assetNumber + " " + assetName).ToString();
                        string assetRevString = "";
                        string concat = temp1;
                        while (assetRev != 0) 
                        {
                            if (assetRev < 10) { assetRevString = "00" + assetRev.ToString(); }
                            else if (assetRev < 100 && assetRev >= 10) { assetRevString = "0" + assetRev.ToString(); }
                            else if (assetRev < 1000 && assetRev >= 100) { assetRevString =  assetRev.ToString(); }
                            concat = concat + "," + Directory.CreateDirectory("G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering\\" + assetNumber + " " + assetName + "\\" + temp1 + " Rev" + assetRevString).ToString();
                            concat = concat + "," + Directory.CreateDirectory("G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering\\" + assetNumber + " " + assetName + "\\" + temp1 + " Rev" + assetRevString + "\\" + "Developmental").ToString();
                            concat = concat + "," + Directory.CreateDirectory("G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering\\" + assetNumber + " " + assetName + "\\" + temp1 + " Rev" + assetRevString + "\\" + "Archive").ToString();
                            assetRev--;
                            Output.Text = concat;
                        }  
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Explore.Content.ToString() == "Switch to Explore")
            {
                Input.Text = "Search";
                Explore.Content = "Switch to Add";
                RefreshListBox(orignalPath);
                Output.Visibility = Visibility.Collapsed;
                Directories.Visibility = Visibility.Visible;
                Directories.ItemsSource = listbox;
                FilesOnly.Visibility = Visibility.Visible;
                DirectoriesOnly.Visibility = Visibility.Visible;

            } else if (Explore.Content.ToString() == "Switch to Add")
            {
                Input.Text = "Enter Asset Number, Asset Name, Rev Number Ex: '32000722,Mega Live Ultrex,001'";
                Output.Text = "Filepath Returns Here";
                Explore.Content = "Switch to Explore";
                RefreshListBox(orignalPath);
                Output.Visibility = Visibility.Visible;
                Directories.Visibility = Visibility.Collapsed;
                Directories.ItemsSource = listbox;
                FilesOnly.Visibility = Visibility.Collapsed;
                DirectoriesOnly.Visibility = Visibility.Collapsed;
            }
        }

        private void RefreshListBox(string path)
        {
            try
            {
                if ((bool)FilesOnly.IsChecked)
                {
                    listbox = new List<string>();
                    string[] temp2 = Directory.GetFiles(path);
                    foreach (string dir in temp2)
                    {
                        listbox.Add(dir);
                    }
                    Directories.ItemsSource = listbox;
                }
                else if ((bool)DirectoriesOnly.IsChecked)
                {
                    listbox = new List<string>();
                    string[] temp1 = Directory.GetDirectories(path);
                    foreach (string dir in temp1)
                    {
                        listbox.Add(dir);
                    }
                    Directories.ItemsSource = listbox;
                }
                else
                {
                    listbox = new List<string>();
                    string[] temp1 = Directory.GetDirectories(path);
                    string[] temp2 = Directory.GetFiles(path);
                    foreach (string dir in temp1)
                    {
                        listbox.Add(dir);
                    }
                    foreach (string dir in temp2)
                    {
                        listbox.Add(dir);
                    }
                    Directories.ItemsSource = listbox;
                }
            }
            catch (System.IO.IOException) { System.Diagnostics.Process.Start(path); }
            catch (System.UnauthorizedAccessException){ Input.Text = "Authorization not granted"; }
        }

        private void Directories_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (Directories.SelectedItem != null)
                {
                    currentDirectory = Directories.SelectedItem.ToString();
                    Input.Text = "Search";
                    RefreshListBox(currentDirectory);
                }
            }
            catch (System.NullReferenceException)
            {
                Input.Text = "Illegal Operation Can't Go Back Any Further";
            }
        }

        private void Input_KeyUp(object sender, KeyEventArgs e)
        {
            if (Explore.Content.ToString() == "Switch to Add")
            {
                listboxTemp = new List<string>();
                foreach (string item in listbox)
                {
                    if (item.ToUpper().Contains(Input.Text.ToUpper()))
                    {
                        listboxTemp.Add(item);
                    }
                }
                Directories.ItemsSource = listboxTemp;
            }
        }

        private void Directories_Back(object sender, RoutedEventArgs e)
        {
            try
            {
                if (currentDirectory.Contains('\\'))
                {
                    int x = currentDirectory.LastIndexOf('\\');
                    currentDirectory = currentDirectory.Substring(0, x);
                } else if (currentDirectory.Contains(':'))
                {
                    int x = currentDirectory.LastIndexOf(':');
                    currentDirectory = currentDirectory.Substring(0, x+1);
                }
                RefreshListBox(currentDirectory);
            }
            catch (System.ArgumentOutOfRangeException) { Input.Text = "Illegal Operation Can't Go Back Any Further"; }
        }

        private void FilesOnly_Checked(object sender, RoutedEventArgs e)
        {          
            
            //this is very stupid prolly a better way to do this.
            if (z == 0)
            {
                if ((bool)FilesOnly.IsChecked) { 
                    y = 1; z = 1; }
                if ((bool)DirectoriesOnly.IsChecked) { 
                    y = 2; z = 1; }
            } else if((bool)FilesOnly.IsChecked && (bool)DirectoriesOnly.IsChecked)
            {
                if (y == 1) { 
                    FilesOnly.IsChecked = false; DirectoriesOnly.IsChecked = true; y = 2; z++;
                }
                else if (y == 2) { 
                    FilesOnly.IsChecked = true; DirectoriesOnly.IsChecked = false; y = 1; z++;
                }

            } else if(!(bool)FilesOnly.IsChecked && !(bool)DirectoriesOnly.IsChecked)
            {
                z = 0;
            }
            else { 
                z--; 
            }

            //randomly unchecks a checkbox
            //if ((bool)FilesOnly.IsChecked && (bool)DirectoriesOnly.IsChecked)
            //{
            //    Random random = new Random();
            //    int x = random.Next(2);
            //    if (x == 0) { FilesOnly.IsChecked = false; }
            //    if (x == 1) { DirectoriesOnly.IsChecked = false; }
            //}

            RefreshListBox(currentDirectory);
        }

        //private void Directories_Selected(object sender, RoutedEventArgs e)
        //{
        //    item = Directories.SelectedItem.ToString();
        //    Copied.Header = item;
        //}

        //private void MenuItem_Click(object sender, RoutedEventArgs e)
        //{
        //    Folders folders = new Folders(item);
        //    ArrayList files = folders.arlistFiles;
        //    ArrayList folder = folders.arlist;
        //    int x = item.Length;
        //    foreach (string item1 in files)
        //    {
        //        item1.Substring(x);
        //        Directory.Move(item1);
        //    }
        //    foreach (string item1 in folder)
        //    {
        //        item1.Substring(x);
        //        Directory.CreateDirectory(item1);
        //    }
        //}    
    }
}
