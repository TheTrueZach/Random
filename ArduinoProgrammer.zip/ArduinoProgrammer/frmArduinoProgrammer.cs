﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Product_Test.Forms
{
    public partial class frmArduinoProgrammer : Form
    {
        private string tmp;
        private frmSplashScreen sf;

        public frmArduinoProgrammer()
        {
            InitializeComponent();

            sf = new frmSplashScreen();
            Thread splashthread = new Thread(new ThreadStart(SplashScreen.ShowSplashScreen));
            splashthread.IsBackground = true;
            splashthread.Start();
            Thread.Sleep(100);

            SplashScreen.UpdateStatusText("Detecting Connected Arduinos!");
            Thread.Sleep(100);
        }

        private void frmArduinoProgrammer_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(@"C:\temp\")) Directory.CreateDirectory(@"C:\temp\");
            File.Copy(@"\\joi\eu\Public\EE Process Test\Software\ArduinoCommandLine\arduino-cli.exe", @"C:\temp\arduino-cli.exe", true);

            string ports = ExcuteCommand("board list");
            string[] saPorts = ports.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 1; i < saPorts.Length; i++) if(saPorts[i].Contains("Serial Port")) cbBoards.Items.Add(saPorts[i].Replace(" serial ", ": "));
            ExcuteCommand("core install arduino:avr");

            SplashScreen.CloseSplashScreen();
            
        }

        private void btnProgram_Click(object sender, EventArgs e)
        {
            if (cbBoards.SelectedIndex == -1 || label1.Text == "<filepath>") return;

            sf = new frmSplashScreen();
            Thread splashthread = new Thread(new ThreadStart(SplashScreen.ShowSplashScreen));
            splashthread.IsBackground = true;
            splashthread.Start();
            Thread.Sleep(100);

            SplashScreen.UpdateStatusText("Programming Arduino!");
            Thread.Sleep(100);

            try
            {
                CopyDirectory(new FileInfo(label1.Text).Directory.FullName, @"C:\temp\" + new FileInfo(label1.Text).Name.Replace(".ino", ""), true, true);
                CopyDirectory(@"\\joi\eu\public\EE Process Test\Software\ArduinoCommandLine\libs\libraries", @"C:\Users\" + Environment.UserName + @"\Documents\Arduino\libraries", true, true);

                string brd = "";
                if (cbBoards.Text.Contains("Mega")) brd = "arduino:avr:mega";
                if (cbBoards.Text.Contains("Uno")) brd = "arduino:avr:uno";

                ExcuteCommand("compile -b " + brd + " \"" + @"C:\temp\" + new FileInfo(label1.Text).Name.Replace(".ino", "") + "\\" + new FileInfo(label1.Text).Name + "\"");
                if (ExcuteCommand("upload -p " + cbBoards.Text.Split(new char[] { ' ' })[0].Replace(":", "") + " --fqbn " + brd + " \"" + @"C:\temp\" + new FileInfo(label1.Text).Name.Replace(".ino", "") + "\\" + new FileInfo(label1.Text).Name + "\" --log-level debug -v").Contains("Error during Upload:"))
                {
                    SplashScreen.CloseSplashScreen();
                    MessageBox.Show("Error during upload!");
                }
                else
                {
                    SplashScreen.CloseSplashScreen();
                    MessageBox.Show("Uploaded!");
                }
            }
            catch (Exception ex) {
                SplashScreen.CloseSplashScreen();
                MessageBox.Show("Error uploading!\n" + ex.Message + "\n" + ex.StackTrace);
            }
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Arduino file (.ino)|*.ino";
            openFileDialog1.DefaultExt = ".ino";

            if (openFileDialog1.ShowDialog() == DialogResult.OK) label1.Text = openFileDialog1.FileName;
        }

        private string ExcuteCommand(string command)
        {
            //string pwd = getPWD();
            //char[] pwdC = pwd.ToCharArray();
            //SecureString SecurePassword = new SecureString();

            //for (int idx = 0; idx < pwdC.Length; idx++)
            //{
            //    SecurePassword.AppendChar(pwdC[idx]);
            //}
            tmp = "";
            Process cmd = new Process();
            //cmd.StartInfo.UserName = "l-bdill";
            //cmd.StartInfo.Password = SecurePassword;
            //cmd.StartInfo.Domain = "JOI";
            cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
            cmd.StartInfo.WorkingDirectory = @"C:\Windows\System32\";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.RedirectStandardError = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.EnableRaisingEvents = true;
            cmd.StartInfo.Arguments = @"/K C:\temp\arduino-cli " + command + "  2>&1";
            cmd.Start();

            Thread t = new Thread(new ThreadStart(delegate {
                char c = (char)0;
                while ((c = (char)cmd.StandardOutput.Read()) != '\uffff')
                    tmp += c;
            }));
            t.Start();

            while (!tmp.Contains(@"C:\Windows\System32>"))
            {
                Thread.Sleep(1);
            }

            cmd.Kill();
            t.Interrupt();
            while (t.IsAlive) { }

            tmp = tmp.Replace("\n\r\nC:\\Windows\\System32>", "");

            richTextBox1.AppendText(@"COMMAND: C:\temp\arduino-cli " + command + "\n\n");

            richTextBox1.AppendText(tmp + "\n\n\n");
            return tmp;
        }

        private string getPWD()
        {
            byte[] key = { 0x02, 0x03, 0xF2, 0x03, 0x03, 0x19, 0x07, 0x08, 0x09, 0x09, 0x11, 0x11, 0x16, 0x07, 0x19, 0x16 };

            try
            {
                // create file stream
                using (FileStream myStream = new FileStream(@"\\joi\eu\public\BlaydeD\PT\encrypted.txt", FileMode.Open))
                {

                    // create instance
                    using (Aes aes = Aes.Create())
                    {

                        // reads IV value
                        byte[] iv = new byte[aes.IV.Length];
                        myStream.Read(iv, 0, iv.Length);

                        // decrypt data
                        using (CryptoStream cryptStream = new CryptoStream(
                           myStream,
                           aes.CreateDecryptor(key, iv),
                           CryptoStreamMode.Read))
                        {

                            // read stream
                            using (StreamReader sReader = new StreamReader(cryptStream))
                            {
                                return sReader.ReadToEnd().Replace("\r\n","");
                            }
                        }
                    }
                }
                Console.ReadKey();
            }
            catch
            {
                throw;
            }
        }

        static void CopyDirectory(string sourceDir, string destinationDir, bool recursive, bool bClearContents)
        {
            // Get information about the source directory
            var dir = new DirectoryInfo(sourceDir);

            // Check if the source directory exists
            if (!dir.Exists)
                throw new DirectoryNotFoundException($"Source directory not found: {dir.FullName}");

            // Cache directories before we start copying
            DirectoryInfo[] dirs = dir.GetDirectories();

            // Create the destination directory
            if (bClearContents)
            {
                if (Directory.Exists(destinationDir)) Directory.Delete(destinationDir, true);

            }
            Directory.CreateDirectory(destinationDir);

            // Get the files in the source directory and copy to the destination directory
            foreach (FileInfo file in dir.GetFiles())
            {
                string targetFilePath = Path.Combine(destinationDir, file.Name);
                file.CopyTo(targetFilePath, true);
            }

            // If recursive and copying subdirectories, recursively call this method
            if (recursive)
            {
                foreach (DirectoryInfo subDir in dirs)
                {
                    string newDestinationDir = Path.Combine(destinationDir, subDir.Name);
                    CopyDirectory(subDir.FullName, newDestinationDir, true, false);
                }
            }
        }
    }
}
