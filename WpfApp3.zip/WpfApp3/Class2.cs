﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3;

namespace WpfApp3
{
    internal class Class2
    {
        public static string Autofill(string[] list, string input)
        {
            int blank = 0;
            string accepted = "";
            foreach (string item in list)
            {
                if (item != null)
                {
                    string check = item.ToUpper();
                    input = input.ToUpper();
                    if (check.Contains(input) && check != null)
                    {
                        blank += 1;
                        if (accepted == "") { accepted = item; }
                        else { accepted = accepted + "\n" + item; }
                    }
                }
            }
            if (blank == 0)
            {
                return "";
            }
            return accepted;
        }
    }
}
