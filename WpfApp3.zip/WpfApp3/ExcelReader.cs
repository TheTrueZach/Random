﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WpfApp3;
using Excel = Microsoft.Office.Interop.Excel;       //microsoft Excel 14 object in references-> COM tab

namespace WpfApp3
{
    internal class ExcelReader
    {
        public string path = (@"C:\Vscode\add2.xlsx");
        public ArrayList parts = new ArrayList();
        public int page;
        public string input = "";
        public bool bottom;
        public int total = 0;
        public bool threadfinished = false;
        public int progress = 0;
        public List<Entry> entries = new List<Entry>();
        public void Reader()
        {
            int x = 0;
            int y = 1;
            int z = 62;
            string part = "";
            if (bottom) { y = 63; z *= 2; z -= 2; }
            //Create COM Objects. Create a COM object for everything that is referenced
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(path);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[page];
            Excel.Range xlRange = xlWorksheet.UsedRange;
            string one = "";
            string two = "";
            string three = "";   
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
            var cellString = "";
            var cellLength = 0;
            //iterate over the rows and columns and print to the console as it appears in the file
            //excel is not zero based!!
            for (int i = y; i <= z; i++)
            {
                for (int j = 1; j <= 3; j++)
                {
                    //new line
                    if (j == 1 && i != 2 && i != 63 && i != 1)
                    {
                        Entry Entry = new Entry(one, two);
                        entries.Add(Entry);
                        parts.Add(part);
                        x++;
                        part = "";
                    }

                    //write the value to the console
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value != null)
                    {
                        cellString = xlRange.Cells[i, j].Value.ToString().Trim();
                        if (cellString.Contains("."))
                        {
                            int count = 0;
                            foreach (char c in cellString)
                            {
                                if (c == '.') count--;
                            }
                            cellLength = cellString.Length + count;

                        }
                        else
                        {
                            cellLength = cellString.Length;
                        }

                        if (j == 1)
                        {
                            part = cellString;
                            one = cellString;
                        }
                        else if (j == 3)
                        {
                            part += cellString;
                            three = cellString;
                        }
                        else if (j == 2)
                        {
                            part += cellString;
                            two = cellString;
                        }
                        else
                        {
                            part += cellString;

                        }
                    }
                    else { part += ""; two = ""; }
                    progress += 1;
                }
            }
            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();
            progress = 80;
            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad
            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);
            progress = 85;
            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);
            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
            total = x;
            threadfinished = true;
        }
    }
}
