﻿using Microsoft.Office.Interop.Excel;
using SharedItems.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using DataTable = System.Data.DataTable;
using Window = System.Windows.Window;


namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //path to the Excel for now.
        //public static string path = System.IO.Directory.GetCurrentDirectory() + @"\add.xlsx";
        public string[] parts;
        public string input = "";
        public int total = 0;
        public int setting = 0;
        public int once = 0;
        public bool cap = false;
        public bool res = false;
        string BOMfilepath;
        DataTable containertable = new DataTable("ParentTable");
        DataTable containertableOG = new DataTable("ParentTable");
        DataTable itemmastertable = new DataTable("ParentTable");
        DataTable itemmastertableOG = new DataTable("ParentTable");
        DataTable z = new DataTable();
        DataRow y;
        int whichPage;


        readonly ExcelReader t1 = new ExcelReader();
        readonly ExcelReader t2 = new ExcelReader();
        readonly ExcelReader t3 = new ExcelReader();
        readonly ExcelReader t4 = new ExcelReader();
        readonly ExcelReader t5 = new ExcelReader();


        public MainWindow()
        {
            InitializeComponent();
            containertable.Clear();
            itemmastertable.Clear();
            DataGridMaker dataGridMaker = new DataGridMaker(containertable, "ContainerID", "PartNumber", "PartDescription");
            DataGridMaker dataGridMaker1 = new DataGridMaker(itemmastertable, "PartNumber", "PartName", "PartDescription");
            YourList yourList = new YourList(z);
            containertable = dataGridMaker.tableout.Copy();
            itemmastertable = dataGridMaker1.tableout.Copy();
            containertableOG = containertable.Copy();
            itemmastertableOG = itemmastertable.Copy();
            Search(1, "tblPartOrganizationalChart", "ContainerID", "PartNumber", "PartDescription");
            Search(2, "ItemMaster", "PartNumber", "PartName", "SearchText");
            DG1.DataContext = containertable;
            DG2.DataContext = itemmastertable;
            DG3.DataContext = z;
            UpdateContainerOG();
            UpdateItemOG();

            //If reading in an excel only.
            Filltable();
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            input = Searchy.Text.ToUpper();
            Update();
        }


        private void Search(int x, string sqltable, string column1, string column2, string column3)
        {
            if (x == 1)
            {
                containertable.Clear();
                DataRow row;
                using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"SELECT * FROM {sqltable} WHERE {column1} LIKE '%{input}%' OR {column2} LIKE '%{input}%' OR {column3} LIKE '%{input}%'ORDER BY ContainerID DESC"))
                {
                    if (tblPartOrganizationalChart.HasRows)
                    {
                        var results = tblPartOrganizationalChart.executeReadQuery();
                        foreach (var result in results)
                        {
                            row = containertable.NewRow();
                            row[column1] = result[column1];
                            row[column2] = result[column2];
                            row[column3] = result[column3];
                            containertable.Rows.Add(row);
                        }
                        containertable.AcceptChanges();
                    }
                }
            }
            if (x == 2)
            {
                itemmastertable.Clear();
                DataRow row;
                using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"SELECT * FROM {sqltable} WHERE ({column1} LIKE '%{input}%' OR {column2} LIKE '%{input}%' OR {column3} LIKE '%{input}%') AND (StockingType <> 'O') AND (XRefItemNumber LIKE '%%') ORDER BY {column1} DESC"))
                {
                    if (tblPartOrganizationalChart.HasRows)
                    {
                        var results = tblPartOrganizationalChart.executeReadQuery();
                        foreach (var result in results)
                        {
                            row = itemmastertable.NewRow();
                            row[column1] = result[column1];
                            row[column2] = result[column2];
                            row["PartDescription"] = result[column3];
                            itemmastertable.Rows.Add(row);
                        }
                        itemmastertable.AcceptChanges();
                    }
                }
            }
        }

        private void UpdateContainerOG() { containertableOG = containertable.Copy(); }
        private void UpdateItemOG() { itemmastertableOG = itemmastertable.Copy(); }

        private void Remove(DataRow remove)
        {
            string delete1 = (string)remove[0];
            string delete2 = (string)remove[1];
            string delete3 = (string)remove[2];
            using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"DELETE FROM tblPartOrganizationalChart WHERE ContainerID = '{delete1}' AND PartNumber = '{delete2}' AND PartDescription = '{delete3}'"))
            {
                var results = tblPartOrganizationalChart.executeNonQuery();
            }
        }

        private void Add(DataRow add)
        {
            string insert1 = (string)add[0];
            string insert2 = (string)add[1];
            string insert3 = "";
            using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"SELECT * FROM ItemMaster WHERE PartNumber = '{insert2}'"))
            {
                var results = tblPartOrganizationalChart.executeReadQuery();
                if (results != null)
                {
                    foreach (var result in results)
                    {
                        insert3 = (String)result["PartName"];
                    }
                }
            }
            using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"INSERT INTO tblPartOrganizationalChart (ContainerID, PartNumber, PartDescription) VALUES ('{insert1}','{insert2}','{insert3}')"))
            {
                var results = tblPartOrganizationalChart.executeNonQuery();
            }
        }

        //This is the delete dialog box.
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            //setup
            DataRow thing1 = containertable.Rows[0];
            int counttest = (containertable.Rows.Count - 1);

            //Checks all the rows that are null, references to an original table.
            for (int count1 = counttest; count1 >= 0; count1--)
            {
                try
                {
                    thing1 = containertable.Rows[count1];
                    string test = (string)thing1[0];
                }
                catch (System.Data.DeletedRowInaccessibleException) { Remove(RowsToDelete(count1)); }
            }
            Search(1, "tblPartOrganizationalChart", "ContainerID", "PartNumber", "PartDescription");
            UpdateContainerOG();
        }

        //This is the add dialog box.
        private void options_Click(object sender, RoutedEventArgs e)
        {
            int countStart;
            countStart = containertableOG.Rows.Count;
            int x = containertable.Rows.Count - containertableOG.Rows.Count;
            while (x >= 0)
            {
                try
                {
                    DataRow thing1 = containertable.Rows[countStart];
                    Add(thing1);
                    x--;
                    countStart++;
                }
                catch { break; }
            }
            Search(1, "tblPartOrganizationalChart", "ContainerID", "PartNumber", "PartDescription");
            UpdateContainerOG();
        }

        private DataRow RowsToDelete(int x)
        {
            //Grabs the datarow from the original table that matched position of nulls in newer table.
            DataRow rowToDel = containertableOG.Rows[x];
            return rowToDel;
        }

        //use if importing an excelfile. Will NOT work if there is duplicate container numbers.
        private void Filltable()
        {
            ExcelReader excelReader = new ExcelReader();

            //Excel File settings.
            excelReader.path = (@"C:\Vscode\add3.xlsx");
            excelReader.page = 1;
            excelReader.bottom = false;
            excelReader.Reader();

            //Stores all the new parts.
            ArrayList parts = excelReader.parts;
            DataRow row;

            //Adds all the new parts.
            foreach (Entry entry in excelReader.entries)
            {
                row = containertable.NewRow();
                row["ContainerID"] = entry.ContainerNum;
                row["PartNumber"] = entry.PartNum;
                row["PartDescription"] = "";
                containertable.Rows.Add(row);
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            cap = true;
            Update();
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            res = true;
            Update();
        }

        private void Update()
        {
            containertable.DefaultView.RowFilter = $"ContainerID LIKE '%{input}%' OR PartNumber Like '%{input}%' OR PartDescription LIKE '%{input}%'";
            if (cap && !res) { itemmastertable.DefaultView.RowFilter = $"PartDescription LIKE '%CAPACITOR%' AND (PartNumber LIKE '%{input}%' OR PartName Like '%{input}%')"; }
            else if (res && !cap) { itemmastertable.DefaultView.RowFilter = $"PartDescription LIKE '%RESISTOR%' AND (PartNumber LIKE '%{input}%' OR PartName Like '%{input}%')"; }
            else { itemmastertable.DefaultView.RowFilter = $"PartNumber LIKE '%{input}%' OR PartName Like '%{input}%' OR PartDescription LIKE '%{input}%'"; }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            cap = false;
            Update();
        }

        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        {
            res = false;
            Update();
        }

        private void options2_Click(object sender, RoutedEventArgs e)
        {
            if (whichPage == 0)
            {
                DataRow row;
                row = z.NewRow();
                row["ContainerID"] = y.ItemArray.ElementAtOrDefault(0);
                row["PartNumber"] = y.ItemArray.ElementAtOrDefault(1);
                row["PartDescription"] = y.ItemArray.ElementAtOrDefault(2);
                z.Rows.Add(row);
            } else if(whichPage == 1) {
                DataRow row;
                row = z.NewRow();
                row["PartName"] = y.ItemArray.ElementAtOrDefault(1);
                row["PartNumber"] = y.ItemArray.ElementAtOrDefault(0);
                row["PartDescription"] = y.ItemArray.ElementAtOrDefault(2);
                z.Rows.Add(row);
            } else if(whichPage == 2)
            {
                try{z.Rows.Remove(y); } catch { }
            }
        }

        private void Import_Click(object sender, RoutedEventArgs e)
        {
            BOMfilepath = BOM.Text;
            Yourlist();
        }

        private void DG1_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try { System.Data.DataRowView x = (System.Data.DataRowView)DG1.CurrentItem; y = x.Row;} catch { };
            try { System.Data.DataRowView x = (System.Data.DataRowView)DG2.CurrentItem; y = x.Row;} catch { };
            try { System.Data.DataRowView x = (System.Data.DataRowView)DG3.CurrentItem; y = x.Row;} catch { };      
        }

        private void TabItem_GotFocus(object sender, RoutedEventArgs e)
        {
            whichPage = 0;
        }

        private void TabItem_GotFocus_1(object sender, RoutedEventArgs e)
        {
            whichPage = 1;
        }

        private void TabItem_GotFocus_2(object sender, RoutedEventArgs e)
        {
            whichPage = 2;
        }

        private void TextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                BOMfilepath = BOM.Text;
                Yourlist();
            }
        }

        private void Yourlist()
        {
            BOMInput bOMInput = new BOMInput(BOMfilepath, 1, 1);
            string[] unpack = bOMInput.PartNumbers;
            DataRow row;
            int match = 0;
            foreach (string item in unpack)
            {
                int x = containertable.Rows.Count - 1;
                int p = 0;
                while (x != 0 && p == 0)
                {
                    if (containertable.Rows[x].ItemArray[1].ToString() == item)
                    {
                        DataRow w = containertable.Rows[x];
                        if (w != null)
                        {
                            row = z.NewRow();
                            row["ContainerID"] = w.ItemArray.ElementAtOrDefault(0);
                            row["PartNumber"] = w.ItemArray.ElementAtOrDefault(1);
                            row["PartDescription"] = w.ItemArray.ElementAtOrDefault(2);
                            row["Designator"] = bOMInput.Designator[match];
                            row["Quantity"] = bOMInput.Quantity[match];
                            z.Rows.Add(row);
                            p = 1;
                        }
                    }
                    x--;
                }
                x = itemmastertable.Rows.Count - 1;
                while (x != 0 && p == 0)
                {
                    if (itemmastertable.Rows[x].ItemArray[0].ToString().Trim() == item)
                    {
                        DataRow w = itemmastertable.Rows[x];
                        if (w != null)
                        {
                            row = z.NewRow();
                            row["PartName"] = w.ItemArray.ElementAtOrDefault(1);
                            row["PartNumber"] = w.ItemArray.ElementAtOrDefault(0);
                            row["PartDescription"] = w.ItemArray.ElementAtOrDefault(2);
                            row["Designator"] = bOMInput.Designator[match];
                            row["Quantity"] = bOMInput.Quantity[match];
                            z.Rows.Add(row);
                            p = 1;
                        }
                    }
                    x--;
                }
                match++;
            }
        }

        private void print_Click(object sender, RoutedEventArgs e)
        {
            var lines = new List<string>();

            string[] columnNames = z.Columns
                .Cast<DataColumn>()
                .Select(column => column.ColumnName)
                .ToArray();

            var header = string.Join(",", columnNames.Select(name => $"\"{name}\""));
            lines.Add(header);

            var valueLines = z.AsEnumerable()
                .Select(row => string.Join(",", row.ItemArray.Select(val => $"\"{val}\"")));

            lines.AddRange(valueLines);

            File.WriteAllLines("excel.csv", lines);
        }
    }
}
