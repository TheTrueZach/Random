﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;       //microsoft Excel 14 object in references-> COM tab

namespace WpfApp3
{
    internal class BOMInput
    {
        private string[] partNumbers;
        public string[] PartNumbers { get { return partNumbers; } set { partNumbers = value; } }
        private string[] designator;
        public string[] Designator { get { return designator; } set { designator = value; } }
        private string[] quantity;
        public string[] Quantity { get { return quantity; } set { quantity = value; } }
        public BOMInput(string path, int page, int columnOfPartNumber)
        {
            string[] tempPartNumbers;
            string[] tempDesignator;
            string[] tempQuantity;
            int x = 0;
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(path);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[page];
            Excel.Range xlRange = xlWorksheet.UsedRange;
            int Designator = 1;
            int Comment = 1;
            int Quanity = 1;
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
            string complete = "";
            for (int i = 1; i <= 1; i++)
            {
                for (int j = 1; j <= colCount; j++)
                {
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value != null)
                    {
                        if(xlRange.Cells[i, j].Value == "Designator") { Designator = j; }
                        if (xlRange.Cells[i, j].Value == "Comment") { Comment = j; }
                    }
                }
            }
            for (int i = 1; i <= rowCount; i++)
            {
                for (int j = 1; j <= 1; j++)
                {
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value != null)
                    {
                        x++;
                    }
                }
            }
            tempPartNumbers = new string[x];
            tempQuantity = new string[x];
            tempDesignator = new string[x];
            x = 0;
            for (int i = 1; i <= rowCount; i++)
            {
                for (int j = Comment; j <= Comment; j++)
                {
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value != null)
                    {
                        tempPartNumbers[x] = xlRange.Cells[i, j].Value;
                    }
                }
                for (int j = Designator; j <= Designator; j++)
                {
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value != null)
                    {
                        tempDesignator[x] = xlRange.Cells[i, j].Value;
                        string source = tempDesignator[x];
                        int count = 1;
                        foreach (char c in source)
                            if (c == ',') count++;
                        tempQuantity[x] = count.ToString();
                    }
                }
                x++;
            }
            partNumbers = new string[tempPartNumbers.Length];
            partNumbers = tempPartNumbers;
            designator = new string[tempDesignator.Length];
            designator = tempDesignator;
            quantity = new string[tempQuantity.Length];
            quantity = tempQuantity;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad
            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);
            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);
            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
        }
    }
}
