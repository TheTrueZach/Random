﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security;
using System.Security.Cryptography;
using System.Reflection.Emit;


namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!Directory.Exists(@"C:\temp\")) Directory.CreateDirectory(@"C:\temp\");
            File.Copy(@"\\joi\eu\Public\EE Process Test\Software\ArduinoCommandLine\arduino-cli.exe", @"C:\temp\arduino-cli.exe", true);

            string ports = ExcuteCommand("board list");
            string[] saPorts = ports.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
        }

        private string ExcuteCommand(string command)
        {
            //string pwd = getPWD();
            //char[] pwdC = pwd.ToCharArray();
            //SecureString SecurePassword = new SecureString();

            //for (int idx = 0; idx < pwdC.Length; idx++)
            //{
            //    SecurePassword.AppendChar(pwdC[idx]);
            //}
            string tmp = "";
            Process cmd = new Process();
            //cmd.StartInfo.UserName = "l-bdill";
            //cmd.StartInfo.Password = SecurePassword;
            //cmd.StartInfo.Domain = "JOI";
            cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
            cmd.StartInfo.WorkingDirectory = @"C:\Windows\System32\";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.RedirectStandardError = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.EnableRaisingEvents = true;
            cmd.StartInfo.Arguments = @"/K C:\temp\arduino-cli " + command + "  2>&1";
            cmd.Start();

            Thread t = new Thread(new ThreadStart(delegate {
                char c = (char)0;
                while ((c = (char)cmd.StandardOutput.Read()) != '\uffff')
                    tmp += c;
            }));
            t.Start();

            while (!tmp.Contains(@"C:\Windows\System32>"))
            {
                Thread.Sleep(1);
            }

            cmd.Kill();
            t.Interrupt();
            while (t.IsAlive) { }

            tmp = tmp.Replace("\n\r\nC:\\Windows\\System32>", "");
            return tmp;
        }

        private void RichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
