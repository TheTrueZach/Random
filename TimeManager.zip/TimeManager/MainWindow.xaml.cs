﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace TimeManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<TaskMaker> tasks = new List<TaskMaker>();
        private long tick;
        private long todaysTicks;
        private long remaining;
        private TimeSpan timeSpan;
        private string[] fileText;
        private Thread thread;
        private bool run = true;
        private bool runfinished = false;
        public MainWindow()
        {
            this.WindowState = WindowState.Maximized;
            InitializeComponent();        
            try
            {
                string ExistingTasks = File.ReadAllText("C:\\Users\\zandrews.JOI\\Desktop\\Tasks\\tasks.txt");
                ExistingTasks = ExistingTasks.Substring(0, ExistingTasks.Length - 1);
                fileText = ExistingTasks.Split('?');
                foreach (string item in fileText)
                {                   
                    TaskMaker taskMaker = new TaskMaker(item);
                    tasks.Add(taskMaker);
                    selector.ItemsSource = new List<Object>();
                    selector.ItemsSource = tasks;
                }
            } catch { fileText = new string[1]; fileText[0] = ""; }
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            //File.WriteAllText("C:\\Users\\zandrews.JOI\\Desktop\\Tasks\\tasks.txt", NewTaskName.Text + "!" + NewTaskInfo.Text + "!" + NewTaskDate.SelectedDate.Value + "!" + NewTaskPriority.Text + "!" + NewTaskAssignment.Text + "?");
            string[] fileTextTemp = fileText;
            fileText = new string[fileTextTemp.Length + 1];
            fileTextTemp.CopyTo(fileText, 0);
            int x = fileText.Length - 1;
            fileText[x] = NewTaskName.Text + "!" + NewTaskInfo.Text + "!" + NewTaskDate.SelectedDate.Value + "!" + NewTaskPriority.Text + "!" + NewTaskAssignment.Text + "!" + NewTaskStatus.Text;
            TaskMaker taskMaker = new TaskMaker(NewTaskName.Text,NewTaskInfo.Text,NewTaskDate.SelectedDate.Value,NewTaskPriority.Text,NewTaskAssignment.Text, NewTaskStatus.Text);
            tasks.Add(taskMaker);
            selector.ItemsSource = new List<Object>();
            selector.ItemsSource = tasks;
        }

        private void ListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TaskMaker taskMaker = (TaskMaker)selector.SelectedItem;
            Update_Current(taskMaker);
        }

        private void Update_Current(TaskMaker current)
        {
            if (current != null)
            {
                CurrentTaskName.Text = current.TaskName;
                CurrentTaskInfo.Text = current.TaskInfo;
                CurrentTaskDate.Text = current.Date.ToString();
                CurrentPriority.Text = current.Priority.ToString();
                CurrentAssignedBy.Text = current.AssignedBy;
                Stat.Text = "Status Of Current Task: " + current.Status;
                tick = current.Date.Ticks;
                todaysTicks = DateTime.Now.Ticks;
                remaining = tick - todaysTicks;
                timeSpan = TimeSpan.FromTicks(remaining);
                DaysLeft.Text = "Days: " + timeSpan.Days.ToString();
                HoursLeft.Text = "Hours: " + timeSpan.Hours.ToString();
                MinutesLeft.Text = "Minutes: " + timeSpan.Minutes.ToString();
                SecondsLeft.Text = "Seconds: " + timeSpan.Seconds.ToString();
                if (thread != null)
                {
                    run = false;
                    thread.Abort();
                    run = true;
                    runfinished = false;
                }
                thread = new Thread(Update_Time);
                thread.Start();
            }
        }

        private void Update_Time()
        {
            while (run == true)
            {
                todaysTicks = DateTime.Now.Ticks;
                remaining = tick - todaysTicks;
                timeSpan = TimeSpan.FromTicks(remaining);
                DaysLeft.Dispatcher.Invoke(new Action(() => { DaysLeft.Text = "Days: " + timeSpan.Days.ToString(); }));
                HoursLeft.Dispatcher.Invoke(new Action(() => { HoursLeft.Text = "Hours: " + timeSpan.Hours.ToString(); }));
                MinutesLeft.Dispatcher.Invoke(new Action(() => { MinutesLeft.Text = "Minutes: " + timeSpan.Minutes.ToString(); }));
                SecondsLeft.Dispatcher.Invoke(new Action(() => { SecondsLeft.Text = "Seconds: " + timeSpan.Seconds.ToString(); }));
            }
            runfinished = true;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string temp = "";
            foreach (string item in fileText)
            {
                if (item != "IGNORE" && item != "")
                {
                    temp += item + "?";
                }
            }
            File.WriteAllText("C:\\Users\\zandrews.JOI\\Desktop\\Tasks\\tasks.txt", temp);
            run = false;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            TaskMaker current = (TaskMaker)selector.SelectedItem;
            tasks.Remove(current);
            selector.ItemsSource = new List<Object>();
            selector.ItemsSource = tasks;
            string check = current.TaskName + "!" + current.TaskInfo + "!" + current.Date + "!" + current.Priority + "!" + current.AssignedBy + "!" + current.Status;
            int x = 0;
            foreach (string item in fileText)
            {
                if (item.Contains(check))
                {
                    fileText[x] = "IGNORE";
                    break;
                }
                x++;
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            TaskMaker current = (TaskMaker)selector.SelectedItem;
            tasks.Remove(current);
            selector.ItemsSource = new List<Object>();
            selector.ItemsSource = tasks;
            string check = current.TaskName + "!" + current.TaskInfo + "!" + current.Date + "!" + current.Priority + "!" + current.AssignedBy + "!" + current.Status;
            int x = 0;
            foreach (string item in fileText)
            {
                if (item.Contains(check))
                {
                    fileText[x] = "IGNORE";
                    break;
                }
                x++;
            }
            NewTaskName.Text = current.TaskName;
            NewTaskDate.SelectedDate = current.Date;
            NewTaskInfo.Text = current.TaskInfo;
            NewTaskPriority.Text = current.Priority.ToString();
            NewTaskAssignment.Text = current.AssignedBy;
            NewTaskStatus.Text = current.Status;
        }

        private void Pass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                string password = "";
                Pass.Dispatcher.Invoke(() => { password = Pass.Password; });
                if(password == "2Efci4r8765!")
                {
                    Pop.IsOpen = false;
                    Pass.Visibility = Visibility.Collapsed;
                    Cal.Visibility = Visibility.Visible;
                    Stat.Visibility = Visibility.Visible;
                    Curr.Visibility = Visibility.Visible;
                    selector.Visibility = Visibility.Visible;
                    Newer.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
