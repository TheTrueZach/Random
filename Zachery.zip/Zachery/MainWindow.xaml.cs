﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace ArduinoUploader
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the path to the Arduino code file from the TextBox.
            string arduinoCodeFilePath = filePathTextBox.Text;

            // Replace with the correct COM port for your Arduino board.
#pragma warning disable CS0219 // Variable is assigned but its value is never used
            string comPort = "COM3"; // Change to your board's COM port.
#pragma warning restore CS0219 // Variable is assigned but its value is never used

            // Replace with the actual path to your Arduino IDE installation directory.
#pragma warning disable CS0219 // Variable is assigned but its value is never used
            string arduinoIdePath = @"C:\Users\zandrews.JOI\Desktop\Arduino\Arduino IDE"; // Replace with your path.
#pragma warning restore CS0219 // Variable is assigned but its value is never used

            // Construct the avrdude command.
            string avrdudeCommand = $"-C\"{"C:\\Program Files (x86)\\Arduino\\hardware\\tools\\avr\\etc\avrdude.conf\" -v -patmega328p -carduino -P{comPort} -b115200 -D -Uflash:w:\"{G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\New_Technician_Interface_Box"}\":i";

            // Create a new process to run avrdude.
            Process avrdudeProcess = new Process();
            avrdudeProcess.StartInfo.FileName = "C:\\Program Files (x86)\\Arduino\\hardware\\tools\\avr\\etc"; // Path to avrdude executable.
            avrdudeProcess.StartInfo.Arguments = avrdudeCommand;
            avrdudeProcess.StartInfo.UseShellExecute = false;
            avrdudeProcess.StartInfo.RedirectStandardOutput = true;
            avrdudeProcess.StartInfo.RedirectStandardError = true;
            avrdudeProcess.StartInfo.CreateNoWindow = true;
            Console.WriteLine("avrdude path: " + avrdudeProcess.StartInfo.FileName);
            Console.WriteLine("avrdude command: " + avrdudeProcess.StartInfo.Arguments);

            try
            {
                avrdudeProcess.Start();
                string output = avrdudeProcess.StandardOutput.ReadToEnd();
                string error = avrdudeProcess.StandardError.ReadToEnd();
                avrdudeProcess.WaitForExit();

                // Handle the output and error messages.
                MessageBox.Show("Upload completed.\n\nOutput:\n" + output, "Upload Status", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error uploading Arduino code:\n" + ex.Message, "Upload Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

