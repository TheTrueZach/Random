﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace tablemaker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string ExistingTasks = File.ReadAllText("C:\\Users\\zandrews.JOI\\Desktop\\format\\formatter.txt");
            string[] tasks = ExistingTasks.Split('\r');
            string[] threefive = new string[10];
            string[] threezero = new string[10];
            string[] twofive = new string[10];
            string[] twozero = new string[10];
            int count = 0;
            int t35 = 0;
            int t30 = 0;
            int t25 = 0;
            int t20 = 0;
            char choice = 'C';
            string choice2 = "5a";
            string changeable = "myDataRow"+choice+"[\"MSL\"] = \"" +   choice2    +"\";\n";
            foreach (string item in tasks)
            {
                if(count == 5) { count = 1; }
                if (count == 0) { threefive[t35] = item; t35++; count = 2; }
                else
                {
                    string temp = item.Substring(1);
                    if (count == 1) { threefive[t35] = temp; t35++; }
                    else if (count == 2) { threezero[t30] = temp; t30++; }
                    else if (count == 3) { twofive[t25] = temp; t25++; }
                    else if (count == 4) { twozero[t20] = temp; t20++; }
                    count++;
                }
            }
            string temp1;
            //temp 35
            int x = 0;
            string output = "myDataRow"+choice+" = Table" + choice +".NewRow();\n" + changeable;
            temp1 = threefive[x];
            if (temp1 == "∞") { temp1 = "0"; }
            output = output + "myDataRow"+choice+"[\"5H\"] = \"" + temp1 + "\";\n";
            foreach (string task in threefive)
            {
                if (x != 0)
                {
                    string temp = task;
                    if (temp == "∞") { temp = "0"; }
                    output = output + "myDataRow"+choice+"[\"" + x * 10 + "H\"] = \"" + temp + "\";\n";
                }
                x++;
            }
            output = output + "myDataRow"+choice+"[\"Temp\"] = \"35\";\n" + "Table"+ choice + ".Rows.Add(myDataRow"+choice+");\n";
            //temp 30
            x = 0;
            output = output + "myDataRow"+choice+" = Table" + choice +".NewRow();\n" + changeable;
            temp1 = threezero[x];
            if (temp1 == "∞") { temp1 = "0"; }
            output = output + "myDataRow"+choice+"[\"5H\"] = \"" + temp1 + "\";\n";
            foreach (string task in threezero)
            {
                if (x != 0)
                {
                    string temp = task;
                    if (temp == "∞") { temp = "0"; }
                    output = output + "myDataRow"+choice+"[\"" + x * 10 + "H\"] = \"" + temp + "\";\n";
                }
                x++;
            }
            output = output + "myDataRow"+choice+"[\"Temp\"] = \"30\";\n" + "Table"+ choice + ".Rows.Add(myDataRow"+choice+");\n";
            //temp 30
            x = 0;
            output = output + "myDataRow"+choice+" = Table" + choice +".NewRow();\n" + changeable;
            temp1 = twofive[x];
            if (temp1 == "∞") { temp1 = "0"; }
            output = output + "myDataRow"+choice+"[\"5H\"] = \"" + temp1 + "\";\n";
            foreach (string task in twofive)
            {
                if (x != 0)
                {
                    string temp = task;
                    if (temp == "∞") { temp = "0"; }
                    output = output + "myDataRow"+choice+"[\"" + x * 10 + "H\"] = \"" + temp + "\";\n";
                }
                x++;
            }
            output = output + "myDataRow"+choice+"[\"Temp\"] = \"25\";\n" + "Table"+ choice + ".Rows.Add(myDataRow"+choice+");\n";
            //temp 30
            x = 0;
            output = output + "myDataRow"+choice+" = Table" + choice +".NewRow();\n" + changeable;
            temp1 = twozero[x];
            if (temp1 == "∞") { temp1 = "0"; }
            output = output + "myDataRow"+choice+"[\"5H\"] = \"" + temp1 + "\";\n";
            foreach (string task in twozero)
            {
                if (x != 0)
                {
                    string temp = task;
                    if (temp == "∞") { temp = "0"; }
                    output = output + "myDataRow"+choice+"[\"" + x * 10 + "H\"] = \"" + temp + "\";\n";
                }
                x++;
            }
            output = output + "myDataRow"+choice+"[\"Temp\"] = \"20\";\n" + "Table"+ choice + ".Rows.Add(myDataRow"+choice+");\n";
            Output.Text = output;
        }
    }
}
