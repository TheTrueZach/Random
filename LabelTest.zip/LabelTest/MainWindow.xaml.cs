﻿using SharedItems.Devices;
using SharedItems.Printing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LabelTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Printer printer = null;
        public MainWindow()
        {
            InitializeComponent();
            printer = DeviceManager.Instance.ImplementPrinter("MSL Label");
            printer.SetMainThread(Dispatcher);         
            SharedItems.Printing.Labels.MSLLabelPrintItem printItem = new SharedItems.Printing.Labels.MSLLabelPrintItem("111000", "2a");
            printer.Preview(printItem);
        }
    }
}
