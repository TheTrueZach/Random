﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class SQLParser
    {
        private string itemNumber;
        private string name;
        private string iD;
        private string additionalFilePaths;
        public string ItemNumber { get { return itemNumber; } set { itemNumber = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string ID { get { return iD; } set { iD = value; } }
        public string AdditionalFilePaths { get { return additionalFilePaths; } set { additionalFilePaths = value; } }

        public SQLParser(string All) 
        {
            string[] tri = All.Split('?');
            itemNumber = tri[0];
            name = tri[1];
            iD = tri[2];
            int x = tri.Length;
            if (x >= 4)
            {
                additionalFilePaths = tri[3];
                string[] AssociatedDocumentPath = tri[3].Split(';');             
                foreach (var item in AssociatedDocumentPath)
                {
                    if (item != null && item != "")
                    {
                        additionalFilePaths += item[1];
                    }
                }
            }
        }
    }
}
