﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class PdfObject
    {
        private string filepath;
        private string pdfname;
        private string type;
        public string Type { get { return type; } set { type = value; } }
        public string PdfName {  get { return pdfname; } set { pdfname = value; } }
        public string Filepath { get { return filepath; } set { filepath = value; } }

        public PdfObject(string pdfFilePath, string typeIn) 
        {
            type = typeIn;
            int x = pdfFilePath.LastIndexOf('\\') + 1;
            int length = pdfFilePath.Length;
            pdfname = pdfFilePath.Substring(x, length - x) + type;
            filepath = pdfFilePath;
        }
    }
}
