﻿using Microsoft.Office.Interop.Word;
using SharedItems.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataTable = System.Data.DataTable;
using System.Diagnostics;
using System.Threading;
using System.Runtime.CompilerServices;
using System.Collections;
using static System.Net.Mime.MediaTypeNames;
using System.ComponentModel;
using System.Management;

namespace BoxCatalog
{
    /// <summary>
    /// Interaction logic for ObjectDisplay.xaml
    /// </summary>
    public partial class ObjectDisplay : System.Windows.Window
    {
        DataTable containertable = new DataTable("ParentTable");
        DataTable itemmastertable = new DataTable("ParentTable");
        DataTable z = new DataTable();
        DataTable boxParts = new DataTable("ParentTable");
        public string input = "";
        private string command;
        private bool teensy = false;
        private string hex = "";
        private readonly List<ComViewer> comViewers = new List<ComViewer>();
        private readonly List<RevBuilder> Revs = new List<RevBuilder>();
        private bool col2 = false;
        private bool col1 = false;
        private string col1Name = "";
        private string col2Name = "";
        private string col3Name = "";
        public ObjectDisplay(Objectmaker current)
        {
            this.WindowState = WindowState.Maximized;
            InitializeComponent();
            this.Title = current.Name;
            string[] revs = Directory.GetDirectories(current.FilePaths);
            foreach (string item in revs)
            {
                int rev = int.Parse(item.Substring(item.Length - 3));
                RevBuilder revBuilder = new RevBuilder(item, rev);
                Revs.Add(revBuilder);
            }
            Boxed.ItemsSource = Revs;
        }

        private void Load(RevBuilder current)
        {
            Boxed.Visibility = Visibility.Collapsed;
            Tbas.Visibility = Visibility.Visible;
            DataGridMaker dataGridMaker = new DataGridMaker(containertable, "ContainerID", "PartNumber", "PartDescription");
            DataGridMaker dataGridMaker1 = new DataGridMaker(itemmastertable, "PartNumber", "PartName", "PartDescription");
            DataGridMaker dataGridMaker2 = new DataGridMaker(boxParts, "Item", "Quantity", "");
            YourList yourList = new YourList(z);
            containertable = dataGridMaker.tableout.Copy();
            itemmastertable = dataGridMaker1.tableout.Copy();
            boxParts = dataGridMaker2.tableout.Copy();
            //Yourlist(current.BOMFilePath);
            Search(1, "tblPartOrganizationalChart", "ContainerID", "PartNumber", "PartDescription");
            Search(2, "ItemMaster", "PartNumber", "PartName", "SearchText");
            
            List<PdfObject> allPdf = new List<PdfObject>();
            List<ArduinoObject> allIno = new List<ArduinoObject>();
            List<BOMObject> allBOM = new List<BOMObject>();
            List<CSVObject> allCSV = new List<CSVObject>();
            List<OtherObject> allOther = new List<OtherObject>();
            List<WordTextObject> allWordText = new List<WordTextObject>();
            foreach (string item in current.Pdf)
            {
                PdfObject pdf = new PdfObject(item, "  <-- In Use");
                allPdf.Add(pdf);
            }
            foreach (string item in current.PdfArchive)
            {
                PdfObject pdf = new PdfObject(item, "  <-- In Archive");
                allPdf.Add(pdf);
            }
            foreach (string item in current.PdfDevelopmental)
            {
                PdfObject pdf = new PdfObject(item, "  <-- In Development");
                allPdf.Add(pdf);
            }
            foreach (string item in current.Arduino)
            {
                int x = item.LastIndexOf('.') - 1;
                if (item[x] == 'T')
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Use, Board: Teensy");
                    allIno.Add(ino);
                }
                else if (item[x] == 'M')
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Use, Board: Mega");
                    allIno.Add(ino);
                }
                else
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Use, Board: Unknown");
                    allIno.Add(ino);
                }
            }
            foreach (string item in current.ArduinoArchive)
            {
                int x = item.LastIndexOf('.') - 1;
                if (item[x] == 'T')
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Archive, Board: Teensy");
                    allIno.Add(ino);
                }
                else if (item[x] == 'M')
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Archive, Board: Mega");
                    allIno.Add(ino);
                }
                else
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Archive, Board: Unknown");
                    allIno.Add(ino);
                }
            }
            foreach (string item in current.ArduinoDevelopmental)
            {
                int x = item.LastIndexOf('.') - 1;
                if (item[x] == 'T')
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Development, Board: Teensy");
                    allIno.Add(ino);
                }
                else if (item[x] == 'M')
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Development, Board: Mega");
                    allIno.Add(ino);
                }
                else
                {
                    ArduinoObject ino = new ArduinoObject(item, "  <-- In Development, Board: Unknown");
                    allIno.Add(ino);
                }
            }
            foreach (string item in current.BOMFilePath)
            {
                BOMObject bom = new BOMObject(item, "  <-- In Use");
                allBOM.Add(bom);
            }
            foreach (string item in current.BOMFilePathArchive)
            {
                BOMObject bom = new BOMObject(item, "  <-- In Archive");
                allBOM.Add(bom);
            }
            foreach (string item in current.BOMFilePathDevelopmental)
            {
                BOMObject bom = new BOMObject(item, "  <-- In Development");
                allBOM.Add(bom);
            }
            foreach (string item in current.Csv)
            {
                CSVObject csv = new CSVObject(item, "  <-- In Use");
                allCSV.Add(csv);
            }
            foreach (string item in current.CsvArchive)
            {
                CSVObject csv = new CSVObject(item, "  <-- In Archive");
                allCSV.Add(csv);
            }
            foreach (string item in current.CsvDevelopmental)
            {
                CSVObject csv = new CSVObject(item, "  <-- In Development");
                allCSV.Add(csv);
            }
            foreach (string item in current.WordText)
            {
                WordTextObject word = new WordTextObject(item, "  <-- In Use");
                allWordText.Add(word);
            }
            foreach (string item in current.WordTextArchive)
            {
                WordTextObject word = new WordTextObject(item, "  <-- In Archive");
                allWordText.Add(word);
            }
            foreach (string item in current.WordTextDevelopmental)
            {
                WordTextObject word = new WordTextObject(item, "  <-- In Development");
                allWordText.Add(word);
            }
            foreach (string item in current.Other)
            {
                OtherObject other = new OtherObject(item, "  <-- In Use");
                allOther.Add(other);
            }
            foreach (string item in current.OtherArchive)
            {
                OtherObject other = new OtherObject(item, "  <-- In Archive");
                allOther.Add(other);
            }
            foreach (string item in current.OtherDevelopmental)
            {
                OtherObject other = new OtherObject(item, "  <-- In Development");
                allOther.Add(other);
            }
            //BoxParts(current.CSVFilePath);
            Pdfs.ItemsSource = allPdf;
            Inos.ItemsSource = allIno;
            BOMS.ItemsSource = allBOM;
            Csvs.ItemsSource = allCSV;
            Word.ItemsSource = allWordText;
            Other.ItemsSource = allOther;
            DG3.DataContext = z;
            DG4.DataContext = boxParts;
        }

        private void Pdfs_Selected(object sender, RoutedEventArgs e)
        {
            PdfObject current;
            current = (PdfObject)Pdfs.SelectedItem;
            if (current != null)
            {
                System.Diagnostics.Process.Start(current.Filepath);
            }
        }

        private void Inos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            BackgroundWorker1_DoWork();
            comViewers.Clear();
            ArduinoObject current;
            current = (ArduinoObject)Inos.SelectedItem;
            if (current != null)
            {
                hex = current.Filepath;
                if (current.Type.Contains("Mega"))
                {
                    teensy = false;
                    using (Process cmd = new Process())
                    {
                        string command = "\"G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\Arduino IDE\\resources\\app\\lib\\backend\\resources\\arduino-cli\" board list";
                        cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                        cmd.StartInfo.CreateNoWindow = true;
                        cmd.StartInfo.RedirectStandardOutput = true;
                        cmd.StartInfo.UseShellExecute = false;
                        cmd.StartInfo.Verb = "runas";
                        cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1";
                        cmd.Start();
                        string output = cmd.StandardOutput.ReadToEnd();
                        string[] tmp = output.Split('\n');
                        foreach (string item in tmp)
                        {
                            ComViewer comViewer = new ComViewer(item, teensy);
                            if (comViewer.Port != null)
                            {
                                comViewers.Add(comViewer);
                            }
                        }
                        cmd.WaitForExit();
                    }
                }
                else if (current.Type.Contains("Teen"))
                {
                    teensy = true;
                    using (Process cmd = new Process())
                    {
                        string command = "\"G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\New folder\\tycmd.exe\" list --verbose";
                        cmd.StartInfo.FileName = @"G:\Process and Test Engrg\EEPT Staff\Code\Arduino Code\HexReferences\New folder\tycmd.exe";
                        cmd.StartInfo.CreateNoWindow = true;
                        cmd.StartInfo.RedirectStandardOutput = true;
                        cmd.StartInfo.UseShellExecute = false;
                        cmd.StartInfo.Verb = "runas";
                        cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1"; ;
                        cmd.Start();
                        string output = cmd.StandardOutput.ReadToEnd();
                        string[] tmp = output.Split('\n');
                        string temp = "";
                        int x = 0;
                        foreach (string item in tmp)
                        {
                            if (item.Contains("Teensy"))
                            {
                                temp = item;
                                x++;
                            }
                            else if (x == 1)
                            {
                                temp += item;
                                string Board = temp.Substring(temp.IndexOf('-') + 8, temp.IndexOf('(') - temp.IndexOf('-') - 8).Trim();
                                string port = temp.Substring(temp.LastIndexOf(':') + 1, temp.LastIndexOf('\r') - temp.LastIndexOf(':')).Trim();
                                ComViewer comViewer = new ComViewer(port, teensy);
                                if (comViewer.Port != null)
                                {
                                    comViewers.Add(comViewer);
                                }
                                x--;
                            }
                        }
                        cmd.WaitForExit();
                    }


                }


                Coms1.ItemsSource = new List<ComViewer>();
                Coms1.ItemsSource = comViewers;
                Tbas.Visibility = Visibility.Collapsed;
                Coms.Visibility = Visibility.Visible;
                //System.Diagnostics.Process.Start(current.Filepath);
                //string command = "\"" + @"\\joi\eu\public\EE Process Test\Software\ArduinoCommandLine\arduino-cli.exe" + "\"" + " upload " + "" + $"{current}" + "" + " -p COM24 -b arduino:avr:mega";
            }
            if(!col1)
            {
                Grid.SetColumn(ChangeableIno, 2);
                col1 = true;
                col1Name = "Ino";
            } 
            else if (!col2)
            {
                Grid.SetColumn(ChangeableIno, 3);
                col2 = true;
                col2Name = "Ino";
            } 
            else
            {
                Grid.SetColumn(ChangeableIno, 4);
                col3Name = "Ino";
            }
            ChangeableIno.Visibility = Visibility.Visible;
        }

        private void Cmd()
        {
            if (!teensy)
            {
                Console.WriteLine(command);
                using (Process cmd = new Process())
                {
                    cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                    //cmd.StartInfo.WorkingDirectory = @"C:\Users\zandrews.JOI";
                    cmd.StartInfo.CreateNoWindow = true;
                    cmd.StartInfo.RedirectStandardOutput = true;
                    cmd.StartInfo.UseShellExecute = false;
                    cmd.StartInfo.Verb = "runas";
                    //cmd.EnableRaisingEvents = true;
                    cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1";
                    cmd.Start();
                    string output = cmd.StandardOutput.ReadToEnd();
                    if (output.Contains("Thank you"))
                    {
                        Uploaded.Text = "Upload Successful Press Enter To Close.";
                        Complete.IsOpen = true;
                        Complete.Visibility = Visibility.Visible;
                        Uploaded.Focus();
                        Complete.Focus();
                    }
                    cmd.WaitForExit();
                }
            }
            else
            {
                Console.WriteLine(command);
                using (Process cmd = new Process())
                {
                    cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                    //cmd.StartInfo.WorkingDirectory = @"C:\Users\zandrews.JOI";
                    cmd.StartInfo.CreateNoWindow = true;
                    cmd.StartInfo.RedirectStandardOutput = true;
                    cmd.StartInfo.UseShellExecute = false;
                    cmd.StartInfo.Verb = "runas";
                    //cmd.EnableRaisingEvents = true;
                    cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1";
                    cmd.Start();
                    string output = cmd.StandardOutput.ReadToEnd();
                    if (output.Contains("Sending reset command"))
                    {
                        Uploaded.Text = "Upload Successful Press Enter To Close.";
                        Complete.IsOpen = true;
                        Complete.Visibility = Visibility.Visible;
                        Uploaded.Focus();
                        Complete.Focus();
                    }
                    cmd.WaitForExit();
                }
            }
        }

        private void ProcessDataReceived(object sender, DataReceivedEventArgs e)
        {
            // Process your output here
            string output = e.Data;
            System.Console.WriteLine(output);
        }

        private void Cmd_Exited(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Yourlist(string BOMfilepath)
        {
            z.Rows.Clear();
            BOMInput bOMInput = new BOMInput(BOMfilepath, 1, 1);
            string[] unpack = bOMInput.PartNumbers;
            DataRow row;
            int match = 0;
            foreach (string item in unpack)
            {
                int x = containertable.Rows.Count - 1;
                int p = 0;
                while (x != 0 && p == 0)
                {
                    if (containertable.Rows[x].ItemArray[1].ToString() == item)
                    {
                        DataRow w = containertable.Rows[x];
                        if (w != null)
                        {
                            row = z.NewRow();
                            row["ContainerID"] = w.ItemArray.ElementAtOrDefault(0);
                            row["PartNumber"] = w.ItemArray.ElementAtOrDefault(1);
                            row["PartDescription"] = w.ItemArray.ElementAtOrDefault(2);
                            row["Designator"] = bOMInput.Designator[match];
                            row["Quantity"] = bOMInput.Quantity[match];
                            z.Rows.Add(row);
                            p = 1;
                        }
                    }
                    x--;
                }
                x = itemmastertable.Rows.Count - 1;
                while (x != 0 && p == 0)
                {
                    if (itemmastertable.Rows[x].ItemArray[0].ToString().Trim() == item)
                    {
                        DataRow w = itemmastertable.Rows[x];
                        if (w != null)
                        {
                            row = z.NewRow();
                            row["ContainerID"] = w.ItemArray.ElementAtOrDefault(1);
                            row["PartNumber"] = w.ItemArray.ElementAtOrDefault(0);
                            row["PartDescription"] = w.ItemArray.ElementAtOrDefault(2);
                            row["Designator"] = bOMInput.Designator[match];
                            row["Quantity"] = bOMInput.Quantity[match];
                            z.Rows.Add(row);
                            p = 1;
                        }
                    }
                    x--;
                }
                if(p == 0)
                {
                    row = z.NewRow();
                    row["ContainerID"] = "";
                    row["PartNumber"] = bOMInput.PartNumbers[match];
                    row["PartDescription"] = "";
                    row["Designator"] = bOMInput.Designator[match];
                    row["Quantity"] = bOMInput.Quantity[match];
                    z.Rows.Add(row);
                    p = 1;
                }
                match++;
            }          
        }

        private void Search(int x, string sqltable, string column1, string column2, string column3)
        {
            if (x == 1)
            {
                containertable.Clear();
                DataRow row;
                using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"SELECT * FROM {sqltable} WHERE {column1} LIKE '%{input}%' OR {column2} LIKE '%{input}%' OR {column3} LIKE '%{input}%'ORDER BY ContainerID DESC"))
                {
                    if (tblPartOrganizationalChart.HasRows)
                    {
                        var results = tblPartOrganizationalChart.executeReadQuery();
                        foreach (var result in results)
                        {
                            row = containertable.NewRow();
                            row[column1] = result[column1];
                            row[column2] = result[column2];
                            row[column3] = result[column3];
                            containertable.Rows.Add(row);
                        }
                        containertable.AcceptChanges();
                    }
                }
            }
            if (x == 2)
            {
                itemmastertable.Clear();
                DataRow row;
                using (SQLHelper tblPartOrganizationalChart = new SQLHelper(SQLServerConnectionHandler.Instance.HummingBirdConnectionString, $"SELECT * FROM {sqltable} WHERE ({column1} LIKE '%{input}%' OR {column2} LIKE '%{input}%' OR {column3} LIKE '%{input}%') AND (StockingType <> 'O') AND (XRefItemNumber LIKE '%%') ORDER BY {column1} DESC"))
                {
                    if (tblPartOrganizationalChart.HasRows)
                    {
                        var results = tblPartOrganizationalChart.executeReadQuery();
                        foreach (var result in results)
                        {
                            row = itemmastertable.NewRow();
                            row[column1] = result[column1];
                            row[column2] = result[column2];
                            row["PartDescription"] = result[column3];
                            itemmastertable.Rows.Add(row);
                        }
                        itemmastertable.AcceptChanges();
                    }
                }
            }
        }

        private void BOMS_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            BOMObject current;
            current = (BOMObject)BOMS.SelectedItem;
            if (current != null)
            {
                Yourlist(current.Filepath);
                BindingOperations.GetBindingExpressionBase((DataGrid)DG3, DataGrid.ItemsSourceProperty).UpdateTarget();
                DG3.Visibility = Visibility.Visible;
                BOMS.Visibility = Visibility.Collapsed;
                if (!col1)
                {
                    Grid.SetColumn(ChangeableBOM, 2);
                    col1 = true;
                    col1Name = "BOM";
                }
                else if (!col2)
                {
                    Grid.SetColumn(ChangeableBOM, 3);
                    col2 = true;
                    col2Name = "BOM";
                }
                else
                {
                    Grid.SetColumn(ChangeableBOM, 4);
                    col3Name = "BOM";
                }
                ChangeableBOM.Visibility = Visibility.Visible;
            }
        }

        private void BoxParts(string csvFilePath)
        {
            if (csvFilePath == null)
            {
                return;
            }
            int x = 0;
            boxParts.Clear();
            DataRow row;
            using (var reader = new StreamReader(csvFilePath))
            {
                while (!reader.EndOfStream)
                {
                    if (x == 0)
                    {
                        var line = reader.ReadLine();
                        x = 1;
                    }
                    if (x == 1) { 
                        var line = reader.ReadLine();
                        var values = line.Split(',');
                        row = boxParts.NewRow();
                        row["Item"] = values[0];
                        row["Quantity"] = values[1];
                        boxParts.Rows.Add(row);                      
                    }
                }
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            DG3.Visibility = Visibility.Collapsed;
            BOMS.Visibility = Visibility.Visible;
        }

        private void Csvs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            CSVObject current;
            current = (CSVObject)Csvs.SelectedItem;
            if (current != null)
            {
                BoxParts(current.Filepath);
                DG4.Visibility = Visibility.Visible;
                Csvs.Visibility = Visibility.Collapsed;
            }
            if (!col1)
            {
                Grid.SetColumn(ChangeableList, 2);
                col1 = true;
                col1Name = "List";
            }
            else if (!col2)
            {
                Grid.SetColumn(ChangeableList, 3);
                col2 = true;
                col1Name = "List";
            }
            else
            {
                Grid.SetColumn(ChangeableList, 4);
                col3Name = "List";
            }
            ChangeableList.Visibility = Visibility.Visible;
        }

        private void Back_Click_1(object sender, RoutedEventArgs e)
        {
            DG4.Visibility = Visibility.Collapsed;
            Csvs.Visibility = Visibility.Visible;
        }

        private void Complete_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                Complete.IsOpen = false;
            }
        }

        private void PreviousScreen_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Boxed_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            RevBuilder current;
            current = (RevBuilder)Boxed.SelectedItem;
            Rev.Visibility = Visibility.Visible;
            if (current != null)
            {
                Load(current);
            }
        }

        private void Other_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            OtherObject current;
            current = (OtherObject)Other.SelectedItem;
            if (current != null)
            {
                System.Diagnostics.Process.Start(current.Filepath);
            }
        }

        private void Word_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            WordTextObject current;
            current = (WordTextObject)Word.SelectedItem;
            if (current != null)
            {
                System.Diagnostics.Process.Start(current.Filepath);
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Wipe();
            DG3.Visibility = Visibility.Collapsed;
            BOMS.Visibility = Visibility.Visible;
            Boxed.Visibility = Visibility.Visible;
            Tbas.Visibility = Visibility.Collapsed;
            Rev.Visibility = Visibility.Collapsed;
        }

        private void Coms_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ComViewer current;
            current = (ComViewer)Coms1.SelectedItem;
            if (current != null)
            {
                if (ComBaudSelector.SelectedItem != null)
                {
                    ComboBoxItem item = ComBaudSelector.SelectedItem as ComboBoxItem;
                    current.Baud = (string)item.Content;
                }
                if (current.Board.Contains("m256"))
                {
                    command = "\"" + @"G:\Process and Test Engrg\EEPT Staff\Code\Arduino Code\HexReferences/avrdude" + "\"" + " \"" + @"-CG:\Process and Test Engrg\EEPT Staff\Code\Arduino Code\HexReferences/avrdude.conf" + "\"" + " -v -V -p" + current.Board + " -cwiring" + " \"" + @"-P" + current.Port + "\"" + " -b" + current.Baud + " -D" + " \"-Uflash:w:" + hex + ":i\"";
                    teensy = false;
                }
                else if (current.Board.Contains("Teen"))
                {
                    command = "\"G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\New folder\\tycmd.exe\" upload --board \"@" + current.Port + "\" \"" + hex + "\"";
                    teensy = true;
                }
                //@"\\joi\eu\Public\EE Process Test\Software\ArduinoCommandLine\arduino-cli.exe" upload "C:\Users\zandrews.JOI\Desktop\RobotVer1\RobotVer1" -p COM24 -b arduino:avr:mega
                //for (int idx = 0; idx < pwdC.Length; idx++)
                //{
                //    SecurePassword.AppendChar(pwdC[idx]);
                //}
                Cmd();
            }
            Tbas.Visibility = Visibility.Visible;
            Coms.Visibility = Visibility.Collapsed;
        }

        private void Wipe()
        {
            containertable = new DataTable();
            itemmastertable = new DataTable();
            z = new DataTable();
            boxParts = new DataTable();
        }

        private void UpdateCOM()
        {
            comViewers.Clear();
            Console.WriteLine("com");
            if (!teensy)
            {
                using (Process cmd = new Process())
                {
                    string command = "\"G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\Arduino IDE\\resources\\app\\lib\\backend\\resources\\arduino-cli\" board list";
                    cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                    cmd.StartInfo.CreateNoWindow = true;
                    cmd.StartInfo.RedirectStandardOutput = true;
                    cmd.StartInfo.UseShellExecute = false;
                    cmd.StartInfo.Verb = "runas";
                    cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1";
                    cmd.Start();
                    string output = cmd.StandardOutput.ReadToEnd();
                    string[] tmp = output.Split('\n');
                    comViewers.Clear();
                    foreach (string item in tmp)
                    {
                        ComViewer comViewer = new ComViewer(item, teensy);
                        if (comViewer.Port != null)
                        {
                            comViewers.Add(comViewer);                         
                        }
                    }
                    cmd.WaitForExit();
                }
            }
            else
            {
                using (Process cmd = new Process())
                {
                    string command = "\"G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\New folder\\tycmd.exe\" list --verbose";
                    cmd.StartInfo.FileName = @"G:\Process and Test Engrg\EEPT Staff\Code\Arduino Code\HexReferences\New folder\tycmd.exe";
                    cmd.StartInfo.CreateNoWindow = true;
                    cmd.StartInfo.RedirectStandardOutput = true;
                    cmd.StartInfo.UseShellExecute = false;
                    cmd.StartInfo.Verb = "runas";
                    cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1"; ;
                    cmd.Start();
                    string output = cmd.StandardOutput.ReadToEnd();
                    string[] tmp = output.Split('\n');
                    string temp = "";
                    int x = 0;
                    comViewers.Clear();
                    foreach (string item in tmp)
                    {
                        if (item.Contains("Teensy"))
                        {
                            temp = item;
                            x++;
                        }
                        else if (x == 1)
                        {
                            temp += item;
                            string Board = temp.Substring(temp.IndexOf('-') + 8, temp.IndexOf('(') - temp.IndexOf('-') - 8).Trim();
                            string port = temp.Substring(temp.LastIndexOf(':') + 1, temp.LastIndexOf('\r') - temp.LastIndexOf(':')).Trim();
                            ComViewer comViewer = new ComViewer(port, teensy);
                            if (comViewer.Port != null)
                            {
                                comViewers.Add(comViewer);                            
                            }
                            x--;
                        }
                    }
                    cmd.WaitForExit();
                }
            }
            Coms1.Dispatcher.Invoke(new Action(() => {
                Coms1.ItemsSource = new List<string>();
                Coms1.ItemsSource = comViewers;
            }));
        }

        private void DeviceInsertedEvent(object sender, EventArrivedEventArgs e)
        {
            comViewers.Clear();
            UpdateCOM();          
        }

        private void DeviceRemovedEvent(object sender, EventArrivedEventArgs e)
        {
            comViewers.Clear();
            UpdateCOM();
        }

        private void BackgroundWorker1_DoWork()
        {
            WqlEventQuery insertQuery = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_SerialPort'");

            ManagementEventWatcher insertWatcher = new ManagementEventWatcher(insertQuery);
            insertWatcher.EventArrived += new EventArrivedEventHandler(DeviceInsertedEvent);
            insertWatcher.Start();

            WqlEventQuery removeQuery = new WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_SerialPort'");
            ManagementEventWatcher removeWatcher = new ManagementEventWatcher(removeQuery);
            removeWatcher.EventArrived += new EventArrivedEventHandler(DeviceRemovedEvent);
            removeWatcher.Start();

            // Do something while waiting for events
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private void ChangeableBom_Click(object sender, RoutedEventArgs e)
        {
            if(col1Name == "BOM") { col1Name = ""; col1 = false; }
            else if (col2Name == "BOM") { col2Name = ""; col2 = false; }
            else if (col3Name == "BOM") { col3Name = ""; }
            ChangeableBOM.Visibility = Visibility.Collapsed;
            DG3.Visibility = Visibility.Collapsed;
            BOMS.Visibility = Visibility.Visible;
        }

        private void ChangeableIno_Click(object sender, RoutedEventArgs e)
        {
            if (col1Name == "Ino") { col1Name = ""; col1 = false; }
            else if (col2Name == "Ino") { col2Name = ""; col2 = false; }
            else if (col3Name == "Ino") { col3Name = ""; }
            ChangeableIno.Visibility = Visibility.Collapsed;
            Tbas.Visibility = Visibility.Visible;
            Coms.Visibility = Visibility.Collapsed;
        }

        private void ChangeableList_Click(object sender, RoutedEventArgs e)
        {
            if (col1Name == "List") { col1Name = ""; col1 = false; }
            else if (col2Name == "List") { col2Name = ""; col2 = false; }
            else if (col3Name == "List") { col3Name = ""; }
            ChangeableList.Visibility = Visibility.Collapsed;
            DG4.Visibility = Visibility.Collapsed;
            Csvs.Visibility = Visibility.Visible;
        }
    }
}
