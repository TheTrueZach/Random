﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class RevBuilder
    {
        private int revNum;
        private string revName;
        private string revBoxVers;
        private string revBoxName;
        private string revBoxNum;
        private string[] ino;
        private string[] csv;
        private string[] pdf;
        private string[] bOMFilePath;
        private string[] png;
        private string[] wordText;
        private string[] other;
        public string[] WordText { get { return wordText; } set { wordText = value; } }
        public string[] Other { get { return other; } set { other = value; } }
        public string[] BOMFilePath { get { return bOMFilePath; } set { bOMFilePath = value; } }
        public string[] Pdf { get { return pdf; } set { pdf = value; } }
        public string[] Png { get { return png; } set { png = value; } }
        public string[] Csv { get { return csv; } set { csv = value; } }
        public string[] Arduino { get { return ino; } set { ino = value; } }    
        public string RevName { get { return revName; } set { revName = value; } }
        public int RevNum { get { return revNum; } set { revNum = value; } }
        public string RevBoxVers { get { return revBoxVers; } set { revBoxVers = value; } }
        public string RevBoxName { get { return revBoxName; } set { revBoxName = value; } }
        public string RevBoxNum { get { return revBoxNum; } set { revBoxNum = value; } }
        private string[] inoArchive;
        private string[] csvArchive;
        private string[] pdfArchive;
        private string[] bOMFilePathArchive;
        private string[] pngArchive;
        private string[] wordTextArchive;
        private string[] otherArchive;
        public string[] WordTextArchive { get { return wordTextArchive; } set { wordTextArchive = value; } }
        public string[] OtherArchive { get { return otherArchive; } set { otherArchive = value; } }
        public string[] BOMFilePathArchive { get { return bOMFilePathArchive; } set { bOMFilePathArchive = value; } }
        public string[] PdfArchive { get { return pdfArchive; } set { pdfArchive = value; } }
        public string[] PngArchive { get { return pngArchive; } set { pngArchive = value; } }
        public string[] CsvArchive { get { return csvArchive; } set { csvArchive = value; } }
        public string[] ArduinoArchive { get { return inoArchive; } set { inoArchive = value; } }
        private string[] inoDevelopmental;
        private string[] csvDevelopmental;
        private string[] pdfDevelopmental;
        private string[] bOMFilePathDevelopmental;
        private string[] pngDevelopmental;
        private string[] wordTextDevelopmental;
        private string[] otherDevelopmental;
        public string[] WordTextDevelopmental { get { return wordTextDevelopmental; } set { wordTextDevelopmental = value; } }
        public string[] OtherDevelopmental { get { return otherDevelopmental; } set { otherDevelopmental = value; } }
        public string[] BOMFilePathDevelopmental { get { return bOMFilePathDevelopmental; } set { bOMFilePathDevelopmental = value; } }
        public string[] PdfDevelopmental { get { return pdfDevelopmental; } set { pdfDevelopmental = value; } }
        public string[] PngDevelopmental { get { return pngDevelopmental; } set { pngDevelopmental = value; } }
        public string[] CsvDevelopmental { get { return csvDevelopmental; } set { csvDevelopmental = value; } }
        public string[] ArduinoDevelopmental { get { return inoDevelopmental; } set { inoDevelopmental = value; } }
        public RevBuilder(string revDirectory, int rev) 
        {
            string revArchive = revDirectory + "\\Archive";
            string revDevelopmental = revDirectory + "\\Developmental";
            Search searchMain = new Search(revDirectory);
            Search searchArchive = new Search(revArchive);
            Search searchDevelopmental = new Search(revDevelopmental);
            revNum = rev;
            revName = revDirectory.Substring(revDirectory.LastIndexOf('\\')+1);
            revBoxName = revName.Substring(0,8);
            revBoxNum = revName.Substring(9,revName.LastIndexOf('R')-9);
            revBoxVers = revName.Substring(revName.Length-6);
            ino = searchMain.Arduino;
            pdf = searchMain.Pdf;
            png = searchMain.Png;
            csv = searchMain.Csv;
            bOMFilePath = searchMain.BOM;
            wordText = searchMain.WordText;
            other = searchMain.Other;
            inoArchive = searchArchive.Arduino;
            pdfArchive = searchArchive.Pdf;
            pngArchive = searchArchive.Png;
            csvArchive = searchArchive.Csv;
            bOMFilePathArchive = searchArchive.BOM;
            wordTextArchive = searchArchive.WordText;
            otherArchive = searchArchive.Other;
            inoDevelopmental = searchDevelopmental.Arduino;
            pdfDevelopmental = searchDevelopmental.Pdf;
            pngDevelopmental = searchDevelopmental.Png;
            csvDevelopmental = searchDevelopmental.Csv;
            bOMFilePathDevelopmental = searchDevelopmental.BOM;
            wordTextDevelopmental = searchDevelopmental.WordText;
            otherDevelopmental = searchDevelopmental.Other;
        }
    }
}
