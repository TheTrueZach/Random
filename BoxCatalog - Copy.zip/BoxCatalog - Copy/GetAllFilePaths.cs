﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BoxCatalog
//{
//    public class GetAllFilePaths
//    {
//        public ArrayList arlist = new ArrayList();
//        public GetAllFilePaths(string start) 
//        {
//            string[] dirs = Directory.GetDirectories(start);
//            foreach (string dir in dirs)
//            {
//                if (Directory.GetDirectories(dir).Length != 0)
//                {
//                    loop(dir);
//                }
//                arlist.Add(dir);
//            }
//        }

//        private void loop(string start) 
//        {
//            string[] dirs = Directory.GetDirectories(start);
//            foreach (string dir in dirs)
//            {
//                if (Directory.GetDirectories(dir).Length != 0)
//                {
//                    loop(dir);
//                }
//                arlist.Add(dir);
//            }
//        }
//    }
//}
