﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class CSVObject
    {
        private string filepath;
        private string cSVName;
        private string type;
        public string Type { get { return type; } set { type = value; } }
        public string CSVName { get { return cSVName; } set { cSVName = value; } }
        public string Filepath { get { return filepath; } set { filepath = value; } }
        public CSVObject(string CSVFilePath, string typeIn) 
        {
            type = typeIn;
            int x = CSVFilePath.LastIndexOf('\\') + 1;
            int length = CSVFilePath.Length;
            cSVName = CSVFilePath.Substring(x, length - x) + type;
            filepath = CSVFilePath;
        }
    }
}
