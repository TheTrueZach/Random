﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class DataGridMaker
    {
        public DataTable tableout;
        public DataGridMaker(DataTable table, string column1, string column2, string column3)
        {
            table.Reset();
            // Create a new DataTable.
            //System.Data.DataTable table = new DataTable("ParentTable");
            // Declare variables for DataColumn and DataRow objects.
            DataColumn column;
            DataRow row;

            // Create new DataColumn, set DataType,
            // ColumnName and add to DataTable.
            column = new DataColumn();
            column.DataType = System.Type.GetType("System.String");
            column.ColumnName = column1;
            column.ReadOnly = false;
            column.Unique = false;
            // Add the Column to the DataColumnCollection.
            table.Columns.Add(column);

            column = new DataColumn();
            column.DataType = System.Type.GetType("System.String");
            column.ColumnName = column2;
            column.ReadOnly = false;
            column.Unique = false;
            // Add the Column to the DataColumnCollection.
            table.Columns.Add(column);
            if (column3 != "")
            {
                column = new DataColumn();
                column.DataType = System.Type.GetType("System.String");
                column.ColumnName = column3;
                column.AutoIncrement = false;
                column.ReadOnly = true;
                column.Unique = false;
                // Add the column to the table.
                table.Columns.Add(column);
            }
            // Make the location column the primary key column.
            row = table.NewRow();
            row[column1] = column1;
            row[column2] = column2;
            if (column3 != "")
            {
                row[column3] = column3;
            }
            table.Rows.Add(row);
            tableout = table.Copy();
        }
    }
}
