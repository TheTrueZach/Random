﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class WordTextObject
    {
        private string filepath;
        private string wordTextName;
        private string type;
        public string Type { get { return type; } set { type = value; } }
        public string WordTextName { get { return wordTextName; } set { wordTextName = value; } }
        public string Filepath { get { return filepath; } set { filepath = value; } }
        public WordTextObject(string wordTextFilePath, string typeIn) 
        {
            type = typeIn;
            int x = wordTextFilePath.LastIndexOf('\\') + 1;
            int length = wordTextFilePath.Length;
            wordTextName = wordTextFilePath.Substring(x, length - x) + type;
            filepath = wordTextFilePath;
        }
    }
}
