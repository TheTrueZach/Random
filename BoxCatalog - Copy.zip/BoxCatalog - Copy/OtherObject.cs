﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class OtherObject
    {
        private string filepath;
        private string otherName;
        private string type;
        public string Type { get { return type; } set { type = value; } }
        public string OtherName { get { return otherName; } set { otherName = value; } }
        public string Filepath { get { return filepath; } set { filepath = value; } }
        public OtherObject(string otherFilePath, string typeIn) 
        {
            type = typeIn;
            int x = otherFilePath.LastIndexOf('\\') + 1;
            int length = otherFilePath.Length;
            otherName = otherFilePath.Substring(x, length - x) + type;
            filepath = otherFilePath;
        }
    }
}
