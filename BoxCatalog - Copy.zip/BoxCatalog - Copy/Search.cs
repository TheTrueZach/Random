﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace BoxCatalog
{
    public class Search
    {
        private string[] arduino;
        private string[] pdf;
        private string[] png;
        private string[] bOM;
        private string[] csv;
        private string[] wordText;
        private string[] other;
        private string filepath;
        public int containsSubFolders;
        public string[] Other { get { return other; } }
        public string[] WordText { get { return wordText; } }
        public string[] Arduino { get { return arduino; } set{ Directory.GetFiles(filepath, "*.ino"); } }
        public string[] Pdf { get { return pdf; } set { Directory.GetFiles(filepath, "*.pdf"); } }
        public string[] Png { get { return png; } set { Directory.GetFiles(filepath, "*.png"); } }
        public string[] BOM { get { return bOM; } set { Directory.GetFiles(filepath, "*.xlsx"); } }
        public string[] Csv { get { return csv; } set { Directory.GetFiles(filepath, "*.csv"); } }

        public Search(string filepathIn) 
        {
            try
            {
                filepath = filepathIn;
                //arduino = Directory.GetFiles(filepath, "*.ino");
                arduino = Directory.GetFiles(filepath, "*.hex");
            } catch(System.ArgumentException) { }
            try
            {
                pdf = Directory.GetFiles(filepath, "*.pdf");
            }
            catch (System.ArgumentException) { }
            try
            {
                png = Directory.GetFiles(filepath, "*.png");
            }
            catch (System.ArgumentException) { }
            try
            {
                string[] temp = Directory.GetFiles(filepath, "*.xlsx");
                List<string> temp1 = new List<string>();
                foreach (string file in temp)
                {
                    if (file.ToUpper().Contains("BOM")) { temp1.Add(file); }
                }
                bOM = temp1.ToArray();
            }
            catch (System.ArgumentException) { }
            try
            {
                string[] temp = Directory.GetFiles(filepath, "*.csv");
                List<string> temp1 = new List<string>();
                foreach (string file in temp)
                {
                    if (file.ToUpper().Contains("LIST")) { temp1.Add(file); }
                }
                csv = temp1.ToArray();
            }
            catch (System.ArgumentException) { }
            try
            {
                string[] temp1 = Directory.GetFiles(filepath, "*.docx");
                string[] temp2 = Directory.GetFiles(filepath, "*.txt");
                wordText = new string[temp1.Length + temp2.Length];
                int x = 0;
                foreach(string s in temp1) { wordText[x] = s;x++; }
                foreach (string s in temp2) { wordText[x] = s; x++; }
            }
            catch (System.ArgumentException) { }
            try
            {
                string[] temp = Directory.GetFiles(filepath);
                List<string> temp1 = new List<string>();
                foreach (string s in temp)
                {
                    if (s.Contains(".pdf")) { }
                    else if (s.Contains(".ino")) { }
                    else if (s.Contains(".png")) { }
                    else if (s.Contains(".xlsx") && s.ToUpper().Contains("BOM")) { }
                    else if (s.Contains(".csv") && s.ToUpper().Contains("LIST")) { }
                    else if (s.Contains(".txt") || s.Contains(".docx")) { }
                    else { temp1.Add(s); }
                }
                other = temp1.ToArray();
            }
            catch (System.ArgumentException) { }
        }
    }
}
