﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

//Use ctrl-f and search "Could Change!" to find possible future modifications.


namespace BoxCatalog
{
    /// <summary>
    /// Interaction logic for FileExplorer.xaml
    /// </summary>
    public partial class FileExplorer : System.Windows.Window
    {
        //List Boxes to display paths.
        public List<string> listbox = new List<string>();
        public List<string> listboxTemp = new List<string>();

        //Paths used by this document.
        public string currentDirectory = "G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering";
        private readonly string orignalPath = "G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering";
        private string trash = "G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering\\TrashCan\\";
        private string ardCli = "G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\Arduino IDE\\resources\\app\\lib\\backend\\resources\\arduino-cli.exe";
        private string hexRef = "G:\\Process and Test Engrg\\EEPT Staff\\Code\\Arduino Code\\HexReferences\\";
        private string processNtest = "G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering\\";

        //Other Random Variables.
        private bool typeing = true;
        private int z = 0;
        private int y = 0;
        private string copied;
        private string deleted;
        private string deletedDir;
        private bool worked;
        private string checkBoard;
        private string checkBaud;
        private string ino;
        public FileExplorer()
        {
            this.WindowState = WindowState.Maximized;
            InitializeComponent();
            RefreshListBox(currentDirectory);
        }

        //Creates a folder for a box with correct format.
        private void TextBox_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            try
            {
                if (Explore.Content.ToString() == "Switch to Explore") //Checks the button to see what code to run.
                {
                    if (e.Key == Key.Return) //Waits for enter to be pressed.
                    {
                        string toBeParsed = Input.Text;
                        toBeParsed = toBeParsed.Trim();
                        string[] temp = toBeParsed.Split(',');
                        if (temp.Length != 3) //Makes sure that the format is correct.
                        {
                            Output.Text = "Failed by Wrong Formatting The correct Format is: \n \"Number,Name,RevNumber\" ex. \"32400370,ModUSB,001\".";
                        }
                        else if (temp.Length == 3) //If it is correct it run the code below.
                        {
                            if (StringCheck(0, temp[0]) && StringCheck(1, temp[1]) && StringCheck(2, temp[2]))
                            {
                                string assetNumber = temp[0];
                                string assetName = temp[1];
                                //string assetRev = temp[2];
                                int assetRev = int.Parse(temp[2]);
                                string temp1 = Directory.CreateDirectory(processNtest + assetNumber + " " + assetName).ToString();
                                string assetRevString = "";
                                string concat = temp1;
                                while (assetRev != 0)
                                {
                                    if (assetRev < 10) { assetRevString = "00" + assetRev.ToString(); }
                                    else if (assetRev < 100 && assetRev >= 10) { assetRevString = "0" + assetRev.ToString(); }
                                    else if (assetRev < 1000 && assetRev >= 100) { assetRevString = assetRev.ToString(); }
                                    concat = concat + "," + Directory.CreateDirectory(processNtest + assetNumber + " " + assetName + "\\" + temp1 + " Rev" + assetRevString).ToString();
                                    concat = concat + "," + Directory.CreateDirectory(processNtest + assetNumber + " " + assetName + "\\" + temp1 + " Rev" + assetRevString + "\\" + "Developmental").ToString();
                                    concat = concat + "," + Directory.CreateDirectory(processNtest + assetNumber + " " + assetName + "\\" + temp1 + " Rev" + assetRevString + "\\" + "Archive").ToString();
                                    assetRev--;
                                    Output.Text = concat;
                                }
                            }
                            else { Output.Text = "Failed by Wrong Formatting The correct Format is: \n \"Number,Name,RevNumber\" ex. \"32400370,ModUSB,001\"."; }
                        }
                    }
                }
            }
            catch (System.IO.IOException)
            {
                Input.Text = "Access Denied!";
            }
        }

        //When the button is clicked it checks what the button say then does the task for that string.
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Explore.Content.ToString() == "Switch to Explore") //Switches to the file explorer.
            {
                Input.Text = "Search";
                Explore.Content = "Switch to Add";
                RefreshListBox(orignalPath);
                Output.Visibility = Visibility.Collapsed;
                Directories.Visibility = Visibility.Visible;
                Directories.ItemsSource = listbox;
                FilesOnly.Visibility = Visibility.Visible;
                DirectoriesOnly.Visibility = Visibility.Visible;
                Dir.Text = "Current Directory: " + currentDirectory;
                typeing = true;
            }
            else if (Explore.Content.ToString() == "Switch to Add") //Switches to the file format adder.
            {
                Input.Text = "Enter Asset Number, Asset Name, Rev Number.";
                Output.Text = "Filepath Returns Here";
                Explore.Content = "Switch to Explore";
                RefreshListBox(orignalPath);
                Output.Visibility = Visibility.Visible;
                Directories.Visibility = Visibility.Collapsed;
                Directories.ItemsSource = listbox;
                FilesOnly.Visibility = Visibility.Collapsed;
                DirectoriesOnly.Visibility = Visibility.Collapsed;
                Dir.Text = "Ex: '32000722,Mega Live Ultrex,001'";
                typeing = true;
            } 
            else if(Explore.Content.ToString() == "Submit Configuration") //Switches to the finish option after creating a hex file from the ino that was double clicked.
            {
                HexCreation();
            } 
            else if(Explore.Content.ToString() == "Finish") //Switches to the file explorer option.
            {
                Upload.Visibility = Visibility.Collapsed;
                Directories.Visibility = Visibility.Visible;
                Explore.Content = "Switch to Add";
                Dir.Text = "Current Directory: " + currentDirectory;
                RefreshListBox(currentDirectory);
                typeing = true;
            }
            else if(Explore.Content.ToString() == "Delete Old Hex")
            {
                string tmp = currentDirectory + "\\" + ino.Substring(ino.LastIndexOf('\\') + 1, ino.Length - ino.LastIndexOf('\\') - 1) + "M.hex";
                string newHex = hexRef + ino.Substring(ino.LastIndexOf('\\') + 1, (ino.Length - ino.LastIndexOf('\\')) - (ino.Length - ino.LastIndexOf('.') + 1)) + "\\" + ino.Substring(ino.LastIndexOf('\\') + 1, ino.Length - ino.LastIndexOf('\\') - 1) + ".hex";
                File.Delete(tmp);
                File.Move(newHex, tmp);
                Upload.Visibility = Visibility.Collapsed;
                Directories.Visibility = Visibility.Visible;
                Explore.Content = "Switch to Add";
                Dir.Text = "Current Directory: " + currentDirectory;
                RefreshListBox(currentDirectory);
                Input.Text = "Hex deleted and new Hex added.";
                typeing = true;
                FilesOnly.Visibility = Visibility.Visible;
                DirectoriesOnly.Visibility = Visibility.Visible;
                Retry.Visibility = Visibility.Collapsed;
            } 
            else if (Explore.Content.ToString() == "Return") 
            {
                Upload.Visibility = Visibility.Collapsed;
                Directories.Visibility = Visibility.Visible;
                Explore.Content = "Switch to Add";
                Dir.Text = "Current Directory: " + currentDirectory;
                RefreshListBox(currentDirectory);
                Input.Text = "Search";
                typeing = true;
                Retry.Visibility = Visibility.Collapsed;
                FilesOnly.Visibility = Visibility.Visible;
                DirectoriesOnly.Visibility = Visibility.Visible;
            }
        }

        //Refreshes the items in the list box.
        private void RefreshListBox(string path)
        {
            if (path.Contains("G:\\G:")) //Deletes the first three charcters if the file path has two G:\G:.
            {
                path = path.Substring(3);
                currentDirectory = currentDirectory.Substring(3);
            }

            try
            {
                if ((bool)FilesOnly.IsChecked) //If the files only checkbox is selected. Only grabs files not the directories.
                {
                    listbox = new List<string>();
                    string[] temp2 = Directory.GetFiles(path);
                    foreach (string dir in temp2)
                    {
                        string dir1 = dir.Substring(dir.LastIndexOf("\\") + 1, dir.Length - dir.LastIndexOf("\\") - 1);
                        listbox.Add(dir1);
                    }
                    Directories.ItemsSource = listbox;
                }
                else if ((bool)DirectoriesOnly.IsChecked) //If the directories only checkbox is selected. Only grabs directories not the files.
                {
                    listbox = new List<string>();
                    string[] temp1 = Directory.GetDirectories(path);
                    foreach (string dir in temp1)
                    {
                        string dir1 = dir.Substring(dir.LastIndexOf("\\") + 1, dir.Length - dir.LastIndexOf("\\") - 1);
                        listbox.Add(dir1);
                    }
                    Directories.ItemsSource = listbox;
                }
                else //Grabs files and directories.
                {
                    listbox = new List<string>();
                    string[] temp1 = Directory.GetDirectories(path);
                    string[] temp2 = Directory.GetFiles(path);
                    foreach (string dir in temp1)
                    {
                        string dir1 = dir.Substring(dir.LastIndexOf("\\") + 1, dir.Length - dir.LastIndexOf("\\") - 1);
                        listbox.Add(dir1);
                    }
                    foreach (string dir in temp2)
                    {
                        string dir1 = dir.Substring(dir.LastIndexOf("\\") + 1, dir.Length - dir.LastIndexOf("\\") - 1);
                        listbox.Add(dir1);
                    }
                    Directories.ItemsSource = listbox;
                }
                //Dir.Text = "Current Directory: " + currentDirectory;
            }
            catch (System.IO.IOException)
            {
                try { System.Diagnostics.Process.Start(path); }
                catch { Input.Text = "Cant Start Program"; }
            }
            catch (System.UnauthorizedAccessException) { Input.Text = "Authorization not granted"; }
        }

        //Gets called when an item in the file explorer is double clicked.
        private void Directories_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (Directories.SelectedItem != null) //Makes sure an item is selected.
                {
                    string temp = currentDirectory + "\\" + Directories.SelectedItem.ToString();
                    if (temp.IndexOf('.') == -1) //Checks to see if the item is a file or directory.
                    {
                        currentDirectory = currentDirectory + "\\" + Directories.SelectedItem.ToString(); //Creates the file path.
                        Input.Text = "Search";
                        typeing = true;
                        Dir.Text = "Current Directory: " + currentDirectory;
                        RefreshListBox(currentDirectory); //Refreshes Screen.
                    }
                    else //Goes here if it is a file.
                    {
                        if (temp.Substring(temp.LastIndexOf('.') + 1, 3) == "ino") //If the file is an ino.
                        {
                            ino = temp;
                            currentDirectory = currentDirectory.Substring(0, currentDirectory.LastIndexOf("\\"));
                            Upload.Visibility = Visibility.Visible;
                            Directories.Visibility = Visibility.Collapsed;
                            FilesOnly.Visibility = Visibility.Collapsed;
                            DirectoriesOnly.Visibility = Visibility.Collapsed;
                            Explore.Content = "Submit Configuration";
                        }
                        else
                        {
                            System.Diagnostics.Process.Start(temp);
                        }
                    }
                }
            }
            catch (System.NullReferenceException) //Not sure what causes this.
            {
                Input.Text = "Illegal Operation Can't Go Back Any Further";
            }
            catch (System.IO.IOException) //Not sure what causes this.
            {
                Input.Text = "Access Denied!";
            }
        }

        //If your in the file explorer screen.
        //Allows you to search for specific files/directories.
        private void Input_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (typeing)
            {
                string letter = e.Key.ToString().ToLower();
                Input.Text = letter;
                typeing = false;
                Input.CaretIndex = 1;
            }

            if (Explore.Content.ToString() == "Switch to Add") //Makes sure the button has this string on it.
            {
                listboxTemp = new List<string>(); //List for the items that match to be added and linked to the display.
                foreach (string item in listbox) //Goes through all file paths on the screen.
                {
                    if (item.ToUpper().Contains(Input.Text.ToUpper())) //Checks to see if the strings contain the query.
                    {
                        listboxTemp.Add(item);
                    }
                }
                Directories.ItemsSource = listboxTemp; //Shows the searched for items.
                Dir.Text = "Current Directory: " + currentDirectory;
            }
        }

        //Context menu option "Back".
        //Goes back one directory everytime it is called.
        private void Directories_Back(object sender, RoutedEventArgs e)
        {
            if (Explore.Content.ToString() == "Switch to Add")
            {
                try
                {
                    if (currentDirectory.Contains('\\')) //Makes sure you still can go back.
                    {
                        int x = currentDirectory.LastIndexOf('\\');
                        currentDirectory = currentDirectory.Substring(0, x);
                    }
                    else if (currentDirectory.Contains(':')) //If you cant go back any further.
                    {
                        int x = currentDirectory.LastIndexOf(':');
                        currentDirectory = currentDirectory.Substring(0, x + 1);
                    }
                    RefreshListBox(currentDirectory); //Refreshes Screen.
                    Dir.Text = "Current Directory: " + currentDirectory;
                }
                catch (System.ArgumentOutOfRangeException) { Input.Text = "Illegal Operation Can't Go Back Any Further"; } //Gets thrown if you try to go to far back.
                catch (System.IO.IOException) //Gets thrown if you try to open a directory your not allowed to.
                {
                    Input.Text = "Access Denied!";
                }
            }
        }

        //Makes it so only one checkbox can be selected at a time.
        //The checkbox is only shown when exploring the filepaths.
        private void FilesOnly_Checked(object sender, RoutedEventArgs e)
        {

            //this is very stupid prolly a better way to do this.
            // Could Change!
            if (z == 0)
            {
                if ((bool)FilesOnly.IsChecked)
                {
                    y = 1; z = 1;
                }
                if ((bool)DirectoriesOnly.IsChecked)
                {
                    y = 2; z = 1;
                }
            }
            else if ((bool)FilesOnly.IsChecked && (bool)DirectoriesOnly.IsChecked)
            {
                if (y == 1)
                {
                    FilesOnly.IsChecked = false; DirectoriesOnly.IsChecked = true; y = 2; z++;
                }
                else if (y == 2)
                {
                    FilesOnly.IsChecked = true; DirectoriesOnly.IsChecked = false; y = 1; z++;
                }

            }
            else if (!(bool)FilesOnly.IsChecked && !(bool)DirectoriesOnly.IsChecked)
            {
                z = 0;
            }
            else
            {
                z--;
            }
            RefreshListBox(currentDirectory); //Refreshes Screen.
        }

        //Context Menu option "Return to Main Window".
        //Closes window.
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {        
            this.Close();
        }

        //Runs if the window is closed either by context menu or the X button.
        private void Window_Closing(object sender, CancelEventArgs e)
        {           
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        //Context menu option "Copy".
        //Copies the selected item for later use.
        private void Directories_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Directories.SelectedItem != null) //Checks to see if an item is selected.
                {
                    copied = Directories.SelectedItem.ToString(); //Grabs current item.
                    Copied.Header = copied; //Set a context menu option to the copied filepath.
                }
                else //If no item is selected.
                {
                    Copied.Header = "Error: No Item Selected";
                }
            }
            catch (System.IO.IOException) //Not sure what causes this.
            {
                Input.Text = "Access Denied!"; 
            }
        }

        //Context menu option "Paste".
        //Pastes the currenly copied file to the current location.
        //Directories will be moved instead.
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                string item = Copied.Header.ToString(); //Grabs the copied string.
                string temp = item.Substring(item.LastIndexOf('\\') + 1, item.Length - item.LastIndexOf('\\') - 1); //Grabs the file name, but leaves out the path.
                string create = currentDirectory + "\\" + temp; //Creates new file path with current directory.
                if (create.IndexOf('.') == -1) //Checks to see if the item is a directory.
                {
                    Directory.Move(copied, currentDirectory);
                    Copied.Header = "Directorys will be moved instead of copied. Complete!";
                }
                else //If it is a file.
                {
                    File.Copy(copied, currentDirectory + "\\" + temp);
                }
                RefreshListBox(currentDirectory); //Refreshes screen.
            }
            catch (System.IO.IOException) //Not sure what causes this.
            {
                Input.Text = "Access Denied!";
            }
        }

        //Context menu option "Delete".
        //Deletes the currently selected file.
        //Does not delete directories.
        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Directories.SelectedItem != null) //Stops null exception from being thrown.
                {
                    string item = Directories.SelectedItem.ToString(); //Gets the string of the current item.
                    Deleted.Header = item; //Sets a line of the context menu as the deleted string.
                    if (item.IndexOf('.') != -1) //Makes sure the user is trying to delete a file instead of directory.
                    {
                        try
                        {
                            try //Tries to move original named file to trash if fails start the iterator.
                            {
                                string newFilePath = trash + item.Substring(item.LastIndexOf('\\') + 1, item.Length - item.LastIndexOf('\\') - 1); //Creates full path where the file is in the trash folder.
                                File.Move(item, newFilePath);
                                deleted = trash + newFilePath; //Stores deleted string if it worked.
                            }
                            catch
                            {
                                worked = false; //Starts while loop.
                                int x = 0; //Naming iterator.
                                while (!worked) //Iterates through infinite potential file names until it finds one that works.
                                {
                                    deleted = copy(item, x);
                                    if(deleted == "Denied")
                                    {
                                        throw new System.IO.IOException();
                                    }
                                    x++;
                                }
                                x = 0;
                            }
                            RefreshListBox(currentDirectory); //Refreshes Screen.
                            deletedDir = currentDirectory + "\\" + item.Substring(item.LastIndexOf('\\') + 1, item.Length - item.LastIndexOf('\\') - 1); //Saves the deleted items full path for future reference.
                        }
                        catch { Deleted.Header = "Error: Failed to Delete."; }//Failed to delete for a variety of reasons.
                    }
                    else { Deleted.Header = "Error: Cant Delete Directory with Program."; } //Program wont let directory be deleted.    Could Change!
                }
                else { Deleted.Header = "Error: No Item Selected."; } //If you try to delete the empty space where there is no item.
            }
            catch (System.IO.IOException) //Not sure what causes this.
            {
                Input.Text = "Access Denied!";
            }
        }

        //Context menu option "Undo Delete".
        //Undo's the most recent deleted string.
        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            try {
                if (deleted != null && deletedDir != null)
                {
                    File.Move(deleted, deletedDir); //Moves the deleted item back to where it was originally.
                    string temp = deletedDir.Substring(0, deletedDir.LastIndexOf('\\')); //Gets the string of where the item was originally deleted so it can refresh it.
                    RefreshListBox(temp); //Refreshes Screen
                }
                else { Deleted.Header = "Error: No Item Deleted"; }
            }
            catch (System.IO.IOException) //Not sure what causes this.
            {
                Input.Text = "Access Denied!";
            }
        }

        //When deleted file gets moved to trash.
        //Only gets here if their is a file with same name already in the trash.
        //Returns the string of the item deleted.
        private string copy(string item, int x)
        {         
            try {
                string maybe = trash + x + "-" + item.Substring(item.LastIndexOf('\\') + 1, item.Length - item.LastIndexOf('\\') - 1); //Creates a new string for the file path with x as the itterator.
                File.Move(item, maybe);
                worked = true; //This breaks out of the while loop calling this function.
                return maybe; //Returns Moved String.
            }
            catch (System.IO.IOException) //Not sure what causes this.
            {
                Input.Text = "Access Denied!";
                return "Denied"; 
            }
            catch { return ""; } //If it doesnt work returns nothing.
        }

        //Gets called when checkbox in GroupBox "Upload" is checked.
        //Makes sure only one check box is selected for the Boards List.
        //Only shown when running ino file via double click.
        private void Mega2560_Checked(object sender, RoutedEventArgs e)
        {
            if ((bool)Mega2560.IsChecked && checkBoard != Mega2560.Content.ToString()) { checkBoard = Mega2560.Content.ToString(); Uno.IsChecked = false; Teensy40.IsChecked = false; Teensy41.IsChecked = false; }
            if ((bool)Uno.IsChecked && checkBoard != Uno.Content.ToString()) { checkBoard = Uno.Content.ToString(); Mega2560.IsChecked = false; Teensy40.IsChecked = false; Teensy41.IsChecked = false; }
            if ((bool)Teensy40.IsChecked && checkBoard != Teensy40.Content.ToString()) { checkBoard = Teensy40.Content.ToString(); Uno.IsChecked = false; Mega2560.IsChecked = false; Teensy41.IsChecked = false; }
            if ((bool)Teensy41.IsChecked && checkBoard != Teensy41.Content.ToString()) { checkBoard = Teensy41.Content.ToString(); Uno.IsChecked = false; Teensy40.IsChecked = false; Mega2560.IsChecked = false; }
        }

        //Gets called when checkbox in GroupBox "Upload" is checked.
        //Makes sure only one check box is selected for the baud rates.
        //Only shown when running ino file via double click.
        private void Baud1_Checked(object sender, RoutedEventArgs e)
        {
            if ((bool)Baud1.IsChecked && checkBaud != Baud1.Content.ToString()) { checkBaud = Baud1.Content.ToString(); Baud2.IsChecked = false; Baud3.IsChecked = false; Baud4.IsChecked = false; Baud5.IsChecked = false; Baud6.IsChecked = false; Baud7.IsChecked = false; }
            if ((bool)Baud2.IsChecked && checkBaud != Baud2.Content.ToString()) { checkBaud = Baud2.Content.ToString(); Baud1.IsChecked = false; Baud3.IsChecked = false; Baud4.IsChecked = false; Baud5.IsChecked = false; Baud6.IsChecked = false; Baud7.IsChecked = false; }
            if ((bool)Baud3.IsChecked && checkBaud != Baud3.Content.ToString()) { checkBaud = Baud3.Content.ToString(); Baud2.IsChecked = false; Baud1.IsChecked = false; Baud4.IsChecked = false; Baud5.IsChecked = false; Baud6.IsChecked = false; Baud7.IsChecked = false; }
            if ((bool)Baud4.IsChecked && checkBaud != Baud4.Content.ToString()) { checkBaud = Baud4.Content.ToString(); Baud2.IsChecked = false; Baud3.IsChecked = false; Baud1.IsChecked = false; Baud5.IsChecked = false; Baud6.IsChecked = false; Baud7.IsChecked = false; }
            if ((bool)Baud5.IsChecked && checkBaud != Baud5.Content.ToString()) { checkBaud = Baud5.Content.ToString(); Baud2.IsChecked = false; Baud3.IsChecked = false; Baud4.IsChecked = false; Baud1.IsChecked = false; Baud6.IsChecked = false; Baud7.IsChecked = false; }
            if ((bool)Baud6.IsChecked && checkBaud != Baud6.Content.ToString()) { checkBaud = Baud6.Content.ToString(); Baud2.IsChecked = false; Baud3.IsChecked = false; Baud4.IsChecked = false; Baud5.IsChecked = false; Baud1.IsChecked = false; Baud7.IsChecked = false; }
            if ((bool)Baud7.IsChecked && checkBaud != Baud7.Content.ToString()) { checkBaud = Baud7.Content.ToString(); Baud2.IsChecked = false; Baud3.IsChecked = false; Baud4.IsChecked = false; Baud5.IsChecked = false; Baud6.IsChecked = false; Baud1.IsChecked = false; }
        }

        //Gets called three times when creating a new file that is formatted.
        private bool StringCheck(int check, string part)
        {
            bool first = true;
            bool second = true;
            bool third = true;
            string[] alpahabet = new string[26];
            alpahabet[0] = "A"; alpahabet[1] = "B"; alpahabet[2] = "C"; alpahabet[3] = "D"; alpahabet[4] = "E"; alpahabet[5] = "F"; alpahabet[6] = "G"; alpahabet[7] = "H"; alpahabet[8] = "I"; alpahabet[9] = "J"; alpahabet[10] = "K"; alpahabet[11] = "L"; alpahabet[12] = "M"; alpahabet[13] = "N"; alpahabet[14] = "O"; alpahabet[15] = "P"; alpahabet[16] = "Q"; alpahabet[17] = "R"; alpahabet[18] = "S"; alpahabet[19] = "T"; alpahabet[20] = "U"; alpahabet[21] = "V"; alpahabet[22] = "W"; alpahabet[23] = "X"; alpahabet[24] = "Y"; alpahabet[25] = "Z";
            int a = 0;
            if (check == 0) //Requirements: Only Numbers, Length of 8.
            {
                if (part.Length == 8)
                {
                    foreach (string item in alpahabet)
                    {
                        if (part.ToUpper().Contains(item)) { first = false; }
                    }
                }
                else { first = false; }
            } 
            else if(check == 1) 
            { 
                if(part == "" || part == null) { second = false; }
            } //Asset Name.
            else if(check == 2) 
            {
                if (part.Length == 3)
                {
                    foreach (string item in alpahabet)
                    {
                        if (part.ToUpper().Contains(item)) { third = false; }
                    }
                }
                else { third = false; }
            } //Requirements: Only Numbers, Length of 3.
            if(first && second && third) { return true; }
            else { return false; }
        }

        private void Retry_Click(object sender, RoutedEventArgs e)
        {
            HexCreation();
        } 

        private void HexCreation()
        {
            string errors = "";
            bool created = false;
            string newdir = hexRef + ino.Substring(ino.LastIndexOf('\\') + 1, (ino.Length - ino.LastIndexOf('\\')) - (ino.Length - ino.LastIndexOf('.') + 1));
            Directory.CreateDirectory(newdir);
            string temp1 = "\"" + ardCli + "\" ";
            string temp2 = " \"" + newdir + "\" ";
            string temp3 = " \"" + ino + "\"";
            string command = temp1 + "-b\"" + checkBoard + "\" compile " + "--build-path" + temp2 + temp3;
            Console.WriteLine(command);
            using (Process cmd = new Process())
            {
                cmd.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                //cmd.StartInfo.WorkingDirectory = @"C:\Users\zandrews.JOI";
                cmd.StartInfo.CreateNoWindow = true;
                cmd.StartInfo.RedirectStandardOutput = true;
                cmd.StartInfo.UseShellExecute = false;
                cmd.StartInfo.Verb = "runas";
                //cmd.EnableRaisingEvents = true;
                cmd.StartInfo.Arguments = @"/C " + "\"" + command + "\" 2>&1";
                cmd.Start();
                string output = cmd.StandardOutput.ReadToEnd();
                if (output.Contains("Sketch uses"))
                {
                    Input.Text = "Hex Creation Successful, Press Finish To Close.";
                    created = true;
                    //Complete.IsOpen = true;
                    //Complete.Visibility = Visibility.Visible;
                    //Uploaded.Focus();
                    //Complete.Focus();
                    Retry.Visibility = Visibility.Collapsed;
                }
                else { created = false; errors = output; }
                cmd.WaitForExit();
            }
            if (created)
            {
                string tmp1 = "";
                string tmp2 = "";
                if (checkBoard == "arduino:avr:mega")
                {
                    tmp2 = ino.Substring(ino.LastIndexOf('\\') + 1, ino.Length - ino.LastIndexOf('\\') - 1) + "M.hex";
                    tmp1 = ino.Substring(ino.LastIndexOf('\\') + 1, ino.Length - ino.LastIndexOf('\\') - 1) + ".hex";
                }
                string part1 = newdir + "\\" + tmp1;
                string part2 = currentDirectory + "\\" + tmp2;
                try
                {
                    File.Move(part1, part2); //Moves the hex to the current folder with format.
                    Explore.Content = "Finish";
                }
                catch
                {
                    Input.Text = "Hex already exists.";
                    Explore.Content = "Delete Old Hex";
                }
            }
            else
            {
                Input.Text = "Error During Hex Creation. Check Error tab for more information.";
                Error.Text = errors;
                Explore.Content = "Return";
                Retry.Visibility = Visibility.Visible;
            }
        }
    }
}
