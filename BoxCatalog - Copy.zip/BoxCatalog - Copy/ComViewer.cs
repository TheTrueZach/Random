﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace BoxCatalog
{
    internal class ComViewer
    {
        private string baud;
        public string Baud { get { return baud; } set { baud = value; } }
        private string port;
        public string Port { get { return port; } set { port = value; } }
        private string board;
        public string Board { get { return board; } set { board = value; } }
        //private string hexFilePath;
        //public string HexFilePath { get { return hexFilePath; } set { hexFilePath = value; } }
        //public ComViewer(string filepath, string type, string input, string hex)
        //public ComViewer(string input)
        //{
        //    //hexFilePath = hex;
        //    string query = "arduino:avr:mega";
        //    baud = "115200";
        //    if (type.Contains("Mega"))
        //    {
        //        board = "m2560";
        //        query = "arduino:avr:mega";
        //    }

        //    if (input.Contains(query) && board != "Teensy")
        //    {
        //        port = input.Substring(0, 6).Trim();
        //    }
        //}
        public ComViewer(string portin, bool teensy)
        {
            if (teensy)
            {
                //hexFilePath= hex;
                baud = "115200";
                board = "Teensy";
                port = portin;
            }
            else
            {
                //hexFilePath = hex;
                baud = "115200";
                board = "m2560";
                if (portin.Contains("Mega")){
                    port = portin.Substring(0, 6).Trim();
                } 
            }
        }
    }
}
