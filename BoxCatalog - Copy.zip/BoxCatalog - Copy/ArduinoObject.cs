﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class ArduinoObject
    {
        private string filepath;
        private string hexfilepath;
        private string arduinoName;
        private string type;
        public string Type { get { return type; } set { type = value; } }
        public string ArduinoName { get { return arduinoName; } set { arduinoName = value; } }
        public string Filepath { get { return filepath; } set { filepath = value; } }
        public string Hexfilepath { get { return hexfilepath; } set { hexfilepath = value; } }


        public ArduinoObject(string inoFilePath, string typeIn)
        {
            type = typeIn;
            if (inoFilePath != "None Available")
            {
                int x = inoFilePath.LastIndexOf('\\') + 1;
                int length = inoFilePath.Length;
                Hexfilepath = inoFilePath.Substring(0, x - 1);
                string[] Hexfilepaths = Directory.GetFiles(Hexfilepath, "*.hex");
                arduinoName = inoFilePath.Substring(x, length - x) + type;
                filepath = inoFilePath;
                foreach (var item in Hexfilepaths)
                {
                    if (item.Contains(arduinoName))
                    {
                        hexfilepath = item;
                    }
                }
            }
        }
    }
}
