﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    
    public class Folders
    {
        public ArrayList arlist = new ArrayList();

        public Folders(string currentfilepath) 
        {
            //arlist.Add(currentfilepath);
            if (currentfilepath != null && currentfilepath != "")
            {
                arlist.Add(currentfilepath);
                loop(currentfilepath);
            }
        }

        private void loop(string start)
        {
            if (start != null && start != "")
            {
                string[] dirs = Directory.GetDirectories(start);
                foreach (string dir in dirs)
                {
                    if (Directory.GetDirectories(dir).Length != 0)
                    {
                        loop(dir);
                    }
                    arlist.Add(dir);
                }
            }
        }

    }
}
