﻿//using Microsoft.Office.Interop.Word;
//using SharedItems.Cobotics;
using SharedItems.Data;
using System;
//using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
//using System.ComponentModel;
//using System.Data;
//using System.Diagnostics;
using System.IO;
//using System.Linq;
//using System.Threading;
using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Data;
//using System.Windows.Documents;
//using static System.Net.Mime.MediaTypeNames;
//using DataTable = System.Data.DataTable;
//using Window = System.Windows.Window;
//using System.Windows.Forms;
//using System.Security.Policy;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Input;
//using Microsoft.Office.Interop.Excel;
//using System.Threading.Tasks;

namespace BoxCatalog
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        public string[] dirs;
        public string[] dirs2;
        private readonly List<Objectmaker> objects = new List<Objectmaker>();
        public MainWindow()
        {
//            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(
//                delegate (object sender, UnhandledExceptionEventArgs args)
//                {
//                    var e = ((Exception)args.ExceptionObject);
//                    var out_msg = $"[UEHandler]: {e.Message}\n" +
//                     $"(Stack Trace)\n{new string('-', 20)}\n\n{e.StackTrace}\n\n{new string('-', 20)}\n" +
//                     $"Will runtime terminate now? -> \'{(args.IsTerminating ? "Yes" : "No")}\'";
//                    Console.WriteLine(out_msg);
//#if !DEBUG
//                    //TODO: Add email stuff
//#endif
//                    if (e is TaskCanceledException tce)
//                    {
//                        var err_msg = $"[UnhandledException] Task: {tce.Task.Id} | CanBeCanceled = {tce.CancellationToken.CanBeCanceled}\n\tSource -> {tce.Source}";
//                        Console.WriteLine(err_msg);
//                    }
//                });
            this.WindowState = WindowState.Maximized;
            InitializeComponent();
            string[] boxes = Sqlread();
            dirs = Directory.GetDirectories("G:\\Process and Test Engrg\\EEPT Specs, Documents, Procedures\\692 Test Engineering");
            int x = 0;
            foreach (string item in boxes)
            {
                Objectmaker objectmaker = new Objectmaker(dirs, item);
                if (objectmaker.FilePaths != null)
                {
                    objects.Add(objectmaker);
                    x++;
                }
            }
            //string item = "32000035?Technician Interface Box?221";
            //Objectmaker objectmaker = new Objectmaker(dirs, item);           
            Boxed.ItemsSource = objects;
        }

        public string[] Sqlread()
        {
            string[] boxes;
            using (SQLHelper Asset_DocumentNumbers = new SQLHelper(SQLServerConnectionHandler.Instance.TestConnectionString, $"SELECT * FROM Asset_DocumentNumbers WHERE (Department LIKE '%EEPT%' OR Subdivision LIKE '%Test Eng%') AND Type LIKE '%Test Fixture%' ORDER BY Asset_DocumentNumber DESC"))
            {
                if (Asset_DocumentNumbers.HasRows)
                {
                    var results = Asset_DocumentNumbers.executeReadQuery();
                    boxes = new string[results.Count];
                    int x = 0;
                    foreach (var result in results)
                    {
                        try 
                        {
                            boxes[x] = (string)result["Asset_DocumentNumber"] + "?" + (string)result["Description"] + "?" + result["ID"].ToString() + "?" + (string)result["AssociatedDocumentPaths"];
                        }
                        catch 
                        {
                            boxes[x] = (string)result["Asset_DocumentNumber"] + "?" + (string)result["Description"] + "?" + result["ID"].ToString();
                        }
                        x++;
                    }
                    return boxes;
                }
                return null;
            }
        }

        private void Boxed_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Objectmaker currently;
            currently = (Objectmaker)Boxed.SelectedItem;
            if (currently != null)
            {
                ObjectDisplay objectDisplay = new ObjectDisplay(currently);
                objectDisplay.Show();
                this.Close();
            }
        }

        private void NewExtraFilePaths_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            Objectmaker current;
            current = (Objectmaker)Boxed.SelectedItem;
            if (e.Key == Key.Return)
            {
                if (NewExtraFilePaths.Text != "" && NewExtraFilePaths.Text != null)
                {
                    string temp = current.FilePaths + "\\ImageForAsset!.png";
                    File.Move(NewExtraFilePaths.Text, temp);
                    UpdateSQL(current);
                }
                Edit.IsOpen = false;
                Boxed.IsEnabled = true;
                //C:\Vscode\battlefrontImage3.png
            }
        }

        private void UpdateSQL(Objectmaker subject)
        {
            string[] boxes;
                //subject.AdditionalFilePaths = update;
            int c = objects.IndexOf(subject);
            using (SQLHelper Asset_DocumentNumbers = new SQLHelper(SQLServerConnectionHandler.Instance.HummingBirdConnectionString, $"SELECT * FROM Asset_DocumentNumbers WHERE ID = '{subject.ID}'"))
            {
                if (Asset_DocumentNumbers.HasRows)
                {
                    var results1 = Asset_DocumentNumbers.executeReadQuery();
                    boxes = new string[results1.Count];
                    int x = 0;
                    foreach (var result in results1)
                    {
                        try
                        {
                            boxes[x] = (string)result["Asset_DocumentNumber"] + "?" + (string)result["Description"] + "?" + result["ID"].ToString() + "?" + (string)result["AssociatedDocumentPaths"];
                        }
                        catch
                        {
                            boxes[x] = (string)result["Asset_DocumentNumber"] + "?" + (string)result["Description"] + "?" + result["ID"].ToString();
                        }
                        Objectmaker objectmaker = new Objectmaker(dirs, boxes[x]);
                        objects[c] = objectmaker;
                        Boxed.Items.Refresh();
                        x++;
                    }
                }
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            NewExtraFilePaths.Text = "";
            Objectmaker current;
            current = (Objectmaker)Boxed.SelectedItem;
            Edit.IsOpen = true;
            Boxed.IsEnabled = false;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            FileExplorer fileExplorer = new FileExplorer();            
            fileExplorer.Show();
            this.Close();
        }

        //private void Window_Closing(object sender, CancelEventArgs e)
        //{
        //    Environment.Exit(0);
        //}

        //private void radDocking_PreviewClose(object sender, BoxCatalog.MainWindow.Windows.Controls.Docking.StateChangeEventArgs e)
        //{

        //    if (HandlePaneClosingEvent != null)

        //    {
        //        if (!HandlePaneClosingEvent())
        //        {
        //            e.Handled = true;
        //        }
        //    }
        //}
    }
}
