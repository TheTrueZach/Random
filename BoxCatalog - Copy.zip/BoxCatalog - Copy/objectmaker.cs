﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    public class Objectmaker
    {
        private string name;
        private string iD;
        private string additionalFilePaths;
        private string filePaths;
        private int revNums;
        private string mainPng;
        private ArrayList list;
        public string MainPng { get { return mainPng; } set { mainPng = value; } }
        public int RevNums { get { return revNums; } set { revNums = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string ID { get { return iD; } set { iD = value; } }
        public string AdditionalFilePaths { get { return additionalFilePaths; } set { additionalFilePaths = value;} }
        public string FilePaths { get { return filePaths; } set { filePaths = value; } }
        public Objectmaker(string[] dirs, string itemnumber)
        {
            SQLParser sQLParser = new SQLParser(itemnumber);
            name = sQLParser.Name;
            //cSVFilePath = sQLParser.CsvPath;
            iD = sQLParser.ID;
            additionalFilePaths = sQLParser.AdditionalFilePaths;
            string test;
            string subnumber;
            string filepath = "";
            if (sQLParser.ItemNumber.Contains("-")) { int z = sQLParser.ItemNumber.LastIndexOf("-"); subnumber = sQLParser.ItemNumber.Substring(z - 3, 3); }
            else { subnumber = sQLParser.ItemNumber.Substring(sQLParser.ItemNumber.Length - 3, 3); }
            foreach (var dir in dirs)
            {
                if (dir.Contains("0")) { test = dir.Substring(dir.LastIndexOf("\\") + 6, 3); }
                else { test = dir; }
                if (test.Contains(subnumber))
                { filepath = dir; }
                else { }
            }
            if (filepath != "" && filepath != null) {
                try { 
                    revNums = Directory.GetDirectories(filepath).Count();
                    Folders folders = new Folders(filepath);
                    list = folders.arlist;
                    filePaths = filepath;
                } catch { revNums = 0; }
                try
                {
                    bool pic = false;
                    foreach (string item in list)
                    {
                        string[] pics = Directory.GetFiles(item, "*!.png");
                        if (pics != null && pics.Length > 0)
                        {
                            mainPng = pics[0];
                            pic = true;
                            break;
                        }
                        else
                        {
                            mainPng = "P:\\Zach3\\PngForBox\\NA.png";
                        }
                    }
                } catch { mainPng = "P:\\Zach3\\PngForBox\\NA.png"; }
            }
            else { mainPng = "P:\\Zach3\\PngForBox\\NA.png"; }
        }
    }
}
