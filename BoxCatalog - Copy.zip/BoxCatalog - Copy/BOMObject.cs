﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxCatalog
{
    internal class BOMObject
    {
        private string filepath;
        private string bOMName;
        private string type;
        public string Type { get { return type; } set { type = value; } }
        public string BOMName { get { return bOMName; } set { bOMName = value; } }
        public string Filepath { get { return filepath; } set { filepath = value; } }


        public BOMObject(string BOMFilePath, string typeIn)
        {
            type = typeIn;
            if (BOMFilePath.ToUpper().Contains("BOM"))
            {
                int x = BOMFilePath.LastIndexOf('\\') + 1;
                int length = BOMFilePath.Length;
                bOMName = BOMFilePath.Substring(x, length - x) + type;
                filepath = BOMFilePath;
            }
        }
    }
}
