﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PartMoistureCalculations
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<PartMaker> objects = new List<PartMaker>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //double mm = double.Parse(Sizemm.Text);
            string msl = MSL.Text;
            PartMaker partMaker = new PartMaker(msl,"","");
            objects.Add(partMaker);
            Parts.ItemsSource = new List<PartMaker>();
            Parts.ItemsSource = objects;
        }

        private void Parts_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
