﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Data;
using System.Diagnostics;

namespace PartMoistureCalculations
{
    internal class PartMaker
    {
        private char partClass;
        private string partMSL;
        private int partMaxRepairableFloorTimeHours;
        private int partDryMultiplier;
        //If 0 this means infinite days
        private int partTotalShelfLifeDays;
        private double typeA = 3.1;
        private double typeC = 2.1;

        public char PartClass {  get { return partClass; } set { partClass = value; } }
        public string PartMSL { get { return partMSL; } set { partMSL = value; } }
        public int PartMaxRepairableFloorTimeHours { get { return partMaxRepairableFloorTimeHours; } set { partMaxRepairableFloorTimeHours = value; } }
        public int PartTotalShelfLifeDays { get { return partTotalShelfLifeDays; } set { partTotalShelfLifeDays = value; } }
        public int PartDryMultiplier { get { return partDryMultiplier; } set { partDryMultiplier = value; } }
        public PartMaker(double bodyThickness, int PartMSLIn) 
        { 
            //if(bodyThickness >= typeA) { partClass = 'A'; }
            //else if(bodyThickness < typeC) { partClass = 'C'; }
            //else { partClass = 'B'; }
            //partMSL = PartMSLIn;
            //if (partMSL == 2 || partMSL == 3)
            //{
            //    if (partMSL == 3) 
            //    {
            //        if (partClass == 'A') { partTotalShelfLifeDays = 13; }
            //        else if (partClass == 'B') { partTotalShelfLifeDays = 15; }
            //        else { partTotalShelfLifeDays = 0; }
            //    }
            //    partDryMultiplier = 5;
            //    partMaxRepairableFloorTimeHours = hoursType1;
            //} 
            //else if( partMSL == 4 || partMSL == 5)
            //{
            //    if (partMSL == 4)
            //    {
            //        if (partClass == 'A') { partTotalShelfLifeDays = 7; }
            //        else if (partClass == 'B') { partTotalShelfLifeDays = 6; }
            //        else { partTotalShelfLifeDays = 9; }
            //    }
            //    if (partMSL == 5)
            //    {
            //        if (partClass == 'A') { partTotalShelfLifeDays = 5; }
            //        else if (partClass == 'B') { partTotalShelfLifeDays = 4; }
            //        else { partTotalShelfLifeDays = 6; }
            //    }
            //    partMaxRepairableFloorTimeHours = hoursType2;
            //    partDryMultiplier = 10;
            //}
        }
        public PartMaker(string PartMSLIn, string humidityIN, string tempIN)
        {
            string humidity;
            string temp = "";
            partMSL = PartMSLIn;
            if (humidityIN!=null && humidityIN!="") { humidity = ((int.Parse(humidityIN) / 10) * 10).ToString(); }
            else { humidity = "40"; }
            if (tempIN == "" || tempIN == null) { temp = "20"; }
            else
            {
                int tempa = ((int)(double.Parse(tempIN) / 5));             
                if (tempa == 7) { temp = "35"; }
                else if (tempa == 6) { temp = "30"; }
                else if (tempa == 5) { temp = "25"; }
                else if (tempa == 4) { temp = "20"; }
                else { temp = "20"; humidity = "40"; }
            }
            PartMakerAll partMakerAll = new PartMakerAll();
            DataTable current;
            partClass = 'A'; current = partMakerAll.DTA;
            DataRow currentRow;
            int a = 0;
            int b = 0;
            int c = 0;
            foreach (DataRow row in current.Rows)
            {
                //Temp can be either 35,30,25,20
                //partMSL can be either 2a,3,4,5,5a
                if ((string)row[11] == temp && (string)row[0] == partMSL)
                {
                    currentRow = row;
                    a = int.Parse((string)currentRow[humidity + "H"]);
                }
            }
            partClass = 'B'; current = partMakerAll.DTB;
            foreach (DataRow row in current.Rows)
            {
                //Temp can be either 35,30,25,20
                //partMSL can be either 2a,3,4,5,5a
                if ((string)row[11] == temp && (string)row[0] == partMSL)
                {
                    currentRow = row;
                    b = int.Parse((string)currentRow[humidity + "H"]);
                }
            }
            partClass = 'C'; current = partMakerAll.DTC;
            foreach (DataRow row in current.Rows) 
            {
                //Temp can be either 35,30,25,20
                //partMSL can be either 2a,3,4,5,5a
                if((string)row[11]==temp && (string)row[0] == partMSL)
                {
                    currentRow = row;
                    c = int.Parse((string)currentRow[humidity + "H"]);
                }
            }
            if (a <= b && a <= c) { partTotalShelfLifeDays = a; partClass = 'A'; }
            else if (b <= a && b <= c) { partTotalShelfLifeDays = b; partClass = 'B'; }
            else { 
                partTotalShelfLifeDays = c; partClass = 'C';
            }
            //humidity has to be in 10% intervals except it also includes 5% and stops at 90%.
            if (PartMSLIn == "2a" || PartMSLIn == "3") { PartDryMultiplier = 5; partMaxRepairableFloorTimeHours = 12; }         
            else if (PartMSLIn == "4" || PartMSLIn == "5" || PartMSLIn == "5a") { partDryMultiplier = 10; partMaxRepairableFloorTimeHours = 8; }
            else {  PartDryMultiplier = 0; partMaxRepairableFloorTimeHours = 0; }











            //if (partMSL == 2 || partMSL == 3)
            //{
            //    if (partMSL == 3)
            //    {
            //        if (partClass == 'A') { partTotalShelfLifeDays = 13; }
            //        else if (partClass == 'B') { partTotalShelfLifeDays = 15; }
            //        else { partTotalShelfLifeDays = 0; }
            //    }
            //    partDryMultiplier = 5;
            //    partMaxRepairableFloorTimeHours = hoursType1;
            //}
            //else if (partMSL == 4 || partMSL == 5)
            //{
            //    if (partMSL == 4)
            //    {
            //        if (partClass == 'A') { partTotalShelfLifeDays = 7; }
            //        else if (partClass == 'B') { partTotalShelfLifeDays = 6; }
            //        else { partTotalShelfLifeDays = 9; }
            //    }
            //    if (partMSL == 5)
            //    {
            //        if (partClass == 'A') { partTotalShelfLifeDays = 5; }
            //        else if (partClass == 'B') { partTotalShelfLifeDays = 4; }
            //        else { partTotalShelfLifeDays = 6; }
            //    }
            //    partMaxRepairableFloorTimeHours = hoursType2;
            //    partDryMultiplier = 10;
            
        }
    }
}
