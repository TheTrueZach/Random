﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartMoistureCalculations
{
    internal class PartMakerAll
    {
        private DataTable dTA;
        public DataTable DTA { get { return dTA; }}
        private DataTable dTB;
        public DataTable DTB { get { return dTB; } }
        private DataTable dTC;
        public DataTable DTC { get { return dTC; } }
        public PartMakerAll() 
        {
            // Create a new DataTable.
            DataTable TableA = new DataTable("TypeA");
            DataColumn dtColumn;
            DataRow myDataRow;

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "MSL";
            dtColumn.Caption = "MSL";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "5H";
            dtColumn.Caption = "5% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "10H";
            dtColumn.Caption = "10% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "20H";
            dtColumn.Caption = "20% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "30H";
            dtColumn.Caption = "30% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "40H";
            dtColumn.Caption = "40% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "50H";
            dtColumn.Caption = "50% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "60H";
            dtColumn.Caption = "60% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "70H";
            dtColumn.Caption = "70% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "80H";
            dtColumn.Caption = "80% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "90H";
            dtColumn.Caption = "90% Humidity";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);

            // Create id column
            dtColumn = new DataColumn();
            dtColumn.DataType = typeof(String);
            dtColumn.ColumnName = "Temp";
            dtColumn.Caption = "Temp";
            dtColumn.ReadOnly = false;
            dtColumn.Unique = false;
            // Add column to the DataColumnCollection.
            TableA.Columns.Add(dtColumn);      
            //MSL 2a
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "2a";
            myDataRow["5H"]  = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "94";
            myDataRow["30H"] = "44";
            myDataRow["40H"] = "32";
            myDataRow["50H"] = "26";
            myDataRow["60H"] = "16";
            myDataRow["70H"] = "7";
            myDataRow["80H"] = "5";
            myDataRow["90H"] = "4";
            myDataRow["Temp"] = "35";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "2a";
            myDataRow["5H"]  = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "124";
            myDataRow["30H"] = "60";
            myDataRow["40H"] = "41";
            myDataRow["50H"] = "33";
            myDataRow["60H"] = "28";
            myDataRow["70H"] = "10";
            myDataRow["80H"] = "7";
            myDataRow["90H"] = "6";
            myDataRow["Temp"] = "30";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "2a";
            myDataRow["5H"]  = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "167";
            myDataRow["30H"] = "78";
            myDataRow["40H"] = "53";
            myDataRow["50H"] = "42";
            myDataRow["60H"] = "36";
            myDataRow["70H"] = "14";
            myDataRow["80H"] = "10";
            myDataRow["90H"] = "8";
            myDataRow["Temp"] = "25";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "2a";
            myDataRow["5H"]  = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "231";
            myDataRow["30H"] = "103";
            myDataRow["40H"] = "69";
            myDataRow["50H"] = "57";
            myDataRow["60H"] = "47";
            myDataRow["70H"] = "19";
            myDataRow["80H"] = "13";
            myDataRow["90H"] = "10";
            myDataRow["Temp"] = "20";
            TableA.Rows.Add(myDataRow);
            //MSL 3
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "3";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "8";
            myDataRow["30H"] = "7";
            myDataRow["40H"] = "6";
            myDataRow["50H"] = "6";
            myDataRow["60H"] = "6";
            myDataRow["70H"] = "4";
            myDataRow["80H"] = "3";
            myDataRow["90H"] = "3";
            myDataRow["Temp"] = "35";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "3";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "10";
            myDataRow["30H"] = "9";
            myDataRow["40H"] = "8";
            myDataRow["50H"] = "7";
            myDataRow["60H"] = "7";
            myDataRow["70H"] = "5";
            myDataRow["80H"] = "4";
            myDataRow["90H"] = "4";
            myDataRow["Temp"] = "30";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "3";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "167";
            myDataRow["30H"] = "78";
            myDataRow["40H"] = "53";
            myDataRow["50H"] = "42";
            myDataRow["60H"] = "36";
            myDataRow["70H"] = "14";
            myDataRow["80H"] = "10";
            myDataRow["90H"] = "8";
            myDataRow["Temp"] = "25";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "3";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "0";
            myDataRow["20H"] = "231";
            myDataRow["30H"] = "103";
            myDataRow["40H"] = "69";
            myDataRow["50H"] = "57";
            myDataRow["60H"] = "47";
            myDataRow["70H"] = "19";
            myDataRow["80H"] = "13";
            myDataRow["90H"] = "10";
            myDataRow["Temp"] = "20";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "4";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "3";
            myDataRow["20H"] = "3";
            myDataRow["30H"] = "3";
            myDataRow["40H"] = "2";
            myDataRow["50H"] = "2";
            myDataRow["60H"] = "2";
            myDataRow["70H"] = "2";
            myDataRow["80H"] = "1";
            myDataRow["90H"] = "1";
            myDataRow["Temp"] = "35";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "4";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "5";
            myDataRow["20H"] = "4";
            myDataRow["30H"] = "4";
            myDataRow["40H"] = "4";
            myDataRow["50H"] = "3";
            myDataRow["60H"] = "3";
            myDataRow["70H"] = "3";
            myDataRow["80H"] = "2";
            myDataRow["90H"] = "2";
            myDataRow["Temp"] = "30";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "4";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "6";
            myDataRow["20H"] = "5";
            myDataRow["30H"] = "5";
            myDataRow["40H"] = "5";
            myDataRow["50H"] = "5";
            myDataRow["60H"] = "4";
            myDataRow["70H"] = "3";
            myDataRow["80H"] = "3";
            myDataRow["90H"] = "3";
            myDataRow["Temp"] = "25";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "4";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "8";
            myDataRow["20H"] = "7";
            myDataRow["30H"] = "7";
            myDataRow["40H"] = "7";
            myDataRow["50H"] = "7";
            myDataRow["60H"] = "6";
            myDataRow["70H"] = "5";
            myDataRow["80H"] = "4";
            myDataRow["90H"] = "4";
            myDataRow["Temp"] = "20";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "2";
            myDataRow["20H"] = "2";
            myDataRow["30H"] = "2";
            myDataRow["40H"] = "2";
            myDataRow["50H"] = "1";
            myDataRow["60H"] = "1";
            myDataRow["70H"] = "1";
            myDataRow["80H"] = "1";
            myDataRow["90H"] = "1";
            myDataRow["Temp"] = "35";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "4";
            myDataRow["20H"] = "3";
            myDataRow["30H"] = "3";
            myDataRow["40H"] = "2";
            myDataRow["50H"] = "2";
            myDataRow["60H"] = "2";
            myDataRow["70H"] = "2";
            myDataRow["80H"] = "1";
            myDataRow["90H"] = "1";
            myDataRow["Temp"] = "30";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "5";
            myDataRow["20H"] = "5";
            myDataRow["30H"] = "4";
            myDataRow["40H"] = "4";
            myDataRow["50H"] = "3";
            myDataRow["60H"] = "3";
            myDataRow["70H"] = "2";
            myDataRow["80H"] = "2";
            myDataRow["90H"] = "2";
            myDataRow["Temp"] = "25";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "7";
            myDataRow["20H"] = "7";
            myDataRow["30H"] = "6";
            myDataRow["40H"] = "5";
            myDataRow["50H"] = "5";
            myDataRow["60H"] = "4";
            myDataRow["70H"] = "3";
            myDataRow["80H"] = "3";
            myDataRow["90H"] = "3";
            myDataRow["Temp"] = "20";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5a";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "1";
            myDataRow["20H"] = "1";
            myDataRow["30H"] = "1";
            myDataRow["40H"] = "1";
            myDataRow["50H"] = "1";
            myDataRow["60H"] = "1";
            myDataRow["70H"] = "1";
            myDataRow["80H"] = "1";
            myDataRow["90H"] = "1";
            myDataRow["Temp"] = "35";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5a";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "2";
            myDataRow["20H"] = "1";
            myDataRow["30H"] = "1";
            myDataRow["40H"] = "1";
            myDataRow["50H"] = "1";
            myDataRow["60H"] = "1";
            myDataRow["70H"] = "1";
            myDataRow["80H"] = "1";
            myDataRow["90H"] = "1";
            myDataRow["Temp"] = "30";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5a";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "3";
            myDataRow["20H"] = "2";
            myDataRow["30H"] = "2";
            myDataRow["40H"] = "2";
            myDataRow["50H"] = "2";
            myDataRow["60H"] = "2";
            myDataRow["70H"] = "1";
            myDataRow["80H"] = "1";
            myDataRow["90H"] = "1";
            myDataRow["Temp"] = "25";
            TableA.Rows.Add(myDataRow);
            myDataRow = TableA.NewRow();
            myDataRow["MSL"] = "5a";
            myDataRow["5H"] = "0";
            myDataRow["10H"] = "5";
            myDataRow["20H"] = "4";
            myDataRow["30H"] = "3";
            myDataRow["40H"] = "3";
            myDataRow["50H"] = "3";
            myDataRow["60H"] = "2";
            myDataRow["70H"] = "2";
            myDataRow["80H"] = "2";
            myDataRow["90H"] = "2";
            myDataRow["Temp"] = "20";
            TableA.Rows.Add(myDataRow);




            // Create a new DataTable.
            DataTable TableB = new DataTable("TypeB");
            DataColumn dtColumnB;
            DataRow myDataRowB;

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "MSL";
            dtColumnB.Caption = "MSL";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "5H";
            dtColumnB.Caption = "5% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "10H";
            dtColumnB.Caption = "10% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "20H";
            dtColumnB.Caption = "20% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "30H";
            dtColumnB.Caption = "30% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "40H";
            dtColumnB.Caption = "40% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "50H";
            dtColumnB.Caption = "50% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "60H";
            dtColumnB.Caption = "60% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "70H";
            dtColumnB.Caption = "70% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "80H";
            dtColumnB.Caption = "80% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "90H";
            dtColumnB.Caption = "90% Humidity";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);

            // Create id column
            dtColumnB = new DataColumn();
            dtColumnB.DataType = typeof(String);
            dtColumnB.ColumnName = "Temp";
            dtColumnB.Caption = "Temp";
            dtColumnB.ReadOnly = false;
            dtColumnB.Unique = false;
            // Add column to the DataColumnCollection.
            TableB.Columns.Add(dtColumnB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "2a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "0";
            myDataRowB["30H"] = "0";
            myDataRowB["40H"] = "58";
            myDataRowB["50H"] = "30";
            myDataRowB["60H"] = "22";
            myDataRowB["70H"] = "3";
            myDataRowB["80H"] = "2";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "35";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "2a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "0";
            myDataRowB["30H"] = "0";
            myDataRowB["40H"] = "86";
            myDataRowB["50H"] = "39";
            myDataRowB["60H"] = "28";
            myDataRowB["70H"] = "4";
            myDataRowB["80H"] = "3";
            myDataRowB["90H"] = "2";
            myDataRowB["Temp"] = "30";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "2a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "0";
            myDataRowB["30H"] = "0";
            myDataRowB["40H"] = "148";
            myDataRowB["50H"] = "51";
            myDataRowB["60H"] = "37";
            myDataRowB["70H"] = "6";
            myDataRowB["80H"] = "4";
            myDataRowB["90H"] = "3";
            myDataRowB["Temp"] = "25";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "2a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "0";
            myDataRowB["30H"] = "0";
            myDataRowB["40H"] = "0";
            myDataRowB["50H"] = "69";
            myDataRowB["60H"] = "49";
            myDataRowB["70H"] = "8";
            myDataRowB["80H"] = "5";
            myDataRowB["90H"] = "4";
            myDataRowB["Temp"] = "20";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "3";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "12";
            myDataRowB["30H"] = "9";
            myDataRowB["40H"] = "7";
            myDataRowB["50H"] = "6";
            myDataRowB["60H"] = "5";
            myDataRowB["70H"] = "2";
            myDataRowB["80H"] = "2";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "35";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "3";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "19";
            myDataRowB["30H"] = "12";
            myDataRowB["40H"] = "9";
            myDataRowB["50H"] = "8";
            myDataRowB["60H"] = "7";
            myDataRowB["70H"] = "3";
            myDataRowB["80H"] = "2";
            myDataRowB["90H"] = "2";
            myDataRowB["Temp"] = "30";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "3";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "25";
            myDataRowB["30H"] = "15";
            myDataRowB["40H"] = "12";
            myDataRowB["50H"] = "10";
            myDataRowB["60H"] = "9";
            myDataRowB["70H"] = "5";
            myDataRowB["80H"] = "3";
            myDataRowB["90H"] = "3";
            myDataRowB["Temp"] = "25";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "3";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "0";
            myDataRowB["20H"] = "32";
            myDataRowB["30H"] = "19";
            myDataRowB["40H"] = "15";
            myDataRowB["50H"] = "13";
            myDataRowB["60H"] = "12";
            myDataRowB["70H"] = "7";
            myDataRowB["80H"] = "5";
            myDataRowB["90H"] = "4";
            myDataRowB["Temp"] = "20";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "4";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "5";
            myDataRowB["20H"] = "4";
            myDataRowB["30H"] = "3";
            myDataRowB["40H"] = "3";
            myDataRowB["50H"] = "2";
            myDataRowB["60H"] = "2";
            myDataRowB["70H"] = "1";
            myDataRowB["80H"] = "1";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "35";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "4";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "7";
            myDataRowB["20H"] = "5";
            myDataRowB["30H"] = "4";
            myDataRowB["40H"] = "4";
            myDataRowB["50H"] = "3";
            myDataRowB["60H"] = "3";
            myDataRowB["70H"] = "2";
            myDataRowB["80H"] = "2";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "30";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "4";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "9";
            myDataRowB["20H"] = "7";
            myDataRowB["30H"] = "5";
            myDataRowB["40H"] = "5";
            myDataRowB["50H"] = "4";
            myDataRowB["60H"] = "4";
            myDataRowB["70H"] = "3";
            myDataRowB["80H"] = "2";
            myDataRowB["90H"] = "2";
            myDataRowB["Temp"] = "25";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "4";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "11";
            myDataRowB["20H"] = "9";
            myDataRowB["30H"] = "7";
            myDataRowB["40H"] = "6";
            myDataRowB["50H"] = "6";
            myDataRowB["60H"] = "5";
            myDataRowB["70H"] = "4";
            myDataRowB["80H"] = "3";
            myDataRowB["90H"] = "3";
            myDataRowB["Temp"] = "20";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "3";
            myDataRowB["20H"] = "2";
            myDataRowB["30H"] = "2";
            myDataRowB["40H"] = "2";
            myDataRowB["50H"] = "2";
            myDataRowB["60H"] = "1";
            myDataRowB["70H"] = "1";
            myDataRowB["80H"] = "1";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "35";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "4";
            myDataRowB["20H"] = "3";
            myDataRowB["30H"] = "3";
            myDataRowB["40H"] = "2";
            myDataRowB["50H"] = "2";
            myDataRowB["60H"] = "2";
            myDataRowB["70H"] = "1";
            myDataRowB["80H"] = "1";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "30";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "5";
            myDataRowB["20H"] = "4";
            myDataRowB["30H"] = "3";
            myDataRowB["40H"] = "3";
            myDataRowB["50H"] = "3";
            myDataRowB["60H"] = "3";
            myDataRowB["70H"] = "2";
            myDataRowB["80H"] = "1";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "25";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "6";
            myDataRowB["20H"] = "5";
            myDataRowB["30H"] = "5";
            myDataRowB["40H"] = "4";
            myDataRowB["50H"] = "4";
            myDataRowB["60H"] = "4";
            myDataRowB["70H"] = "3";
            myDataRowB["80H"] = "3";
            myDataRowB["90H"] = "2";
            myDataRowB["Temp"] = "20";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "1";
            myDataRowB["20H"] = "1";
            myDataRowB["30H"] = "1";
            myDataRowB["40H"] = "1";
            myDataRowB["50H"] = "1";
            myDataRowB["60H"] = "1";
            myDataRowB["70H"] = "1";
            myDataRowB["80H"] = "0.5";
            myDataRowB["90H"] = "0.5";
            myDataRowB["Temp"] = "35";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "2";
            myDataRowB["20H"] = "1";
            myDataRowB["30H"] = "1";
            myDataRowB["40H"] = "1";
            myDataRowB["50H"] = "1";
            myDataRowB["60H"] = "1";
            myDataRowB["70H"] = "1";
            myDataRowB["80H"] = "0.5";
            myDataRowB["90H"] = "0.5";
            myDataRowB["Temp"] = "30";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "2";
            myDataRowB["20H"] = "2";
            myDataRowB["30H"] = "2";
            myDataRowB["40H"] = "2";
            myDataRowB["50H"] = "2";
            myDataRowB["60H"] = "2";
            myDataRowB["70H"] = "1";
            myDataRowB["80H"] = "1";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "25";
            TableB.Rows.Add(myDataRowB);
            myDataRowB = TableB.NewRow();
            myDataRowB["MSL"] = "5a";
            myDataRowB["5H"] = "0";
            myDataRowB["10H"] = "3";
            myDataRowB["20H"] = "2";
            myDataRowB["30H"] = "2";
            myDataRowB["40H"] = "2";
            myDataRowB["50H"] = "2";
            myDataRowB["60H"] = "2";
            myDataRowB["70H"] = "2";
            myDataRowB["80H"] = "2";
            myDataRowB["90H"] = "1";
            myDataRowB["Temp"] = "20";
            TableB.Rows.Add(myDataRowB);


            DataTable TableC = new DataTable("TypeC");
            DataColumn dtColumnC;
            DataRow myDataRowC;
            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "MSL";
            dtColumnC.Caption = "MSL";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "5H";
            dtColumnC.Caption = "5% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "10H";
            dtColumnC.Caption = "10% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "20H";
            dtColumnC.Caption = "20% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "30H";
            dtColumnC.Caption = "30% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "40H";
            dtColumnC.Caption = "40% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "50H";
            dtColumnC.Caption = "50% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "60H";
            dtColumnC.Caption = "60% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "70H";
            dtColumnC.Caption = "70% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "80H";
            dtColumnC.Caption = "80% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "90H";
            dtColumnC.Caption = "90% Humidity";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);

            // Create id column
            dtColumnC = new DataColumn();
            dtColumnC.DataType = typeof(String);
            dtColumnC.ColumnName = "Temp";
            dtColumnC.Caption = "Temp";
            dtColumnC.ReadOnly = false;
            dtColumnC.Unique = false;
            // Add column to the DataColumnCollection.
            TableC.Columns.Add(dtColumnC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "2a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "0";
            myDataRowC["60H"] = "17";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "0.5";
            myDataRowC["90H"] = "0.5";
            myDataRowC["Temp"] = "35";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "2a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "0";
            myDataRowC["60H"] = "28";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "30";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "2a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "0";
            myDataRowC["60H"] = "0";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "25";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "2a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "0";
            myDataRowC["60H"] = "0";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "2";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "20";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "3";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "8";
            myDataRowC["60H"] = "5";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "0.5";
            myDataRowC["90H"] = "0.5";
            myDataRowC["Temp"] = "35";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "3";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "11";
            myDataRowC["60H"] = "7";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "30";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "3";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "14";
            myDataRowC["60H"] = "10";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "25";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "3";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "0";
            myDataRowC["40H"] = "0";
            myDataRowC["50H"] = "20";
            myDataRowC["60H"] = "13";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "2";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "20";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "4";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "7";
            myDataRowC["40H"] = "4";
            myDataRowC["50H"] = "3";
            myDataRowC["60H"] = "2";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "0.5";
            myDataRowC["90H"] = "0.5";
            myDataRowC["Temp"] = "35";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "4";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "9";
            myDataRowC["40H"] = "5";
            myDataRowC["50H"] = "4";
            myDataRowC["60H"] = "3";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "30";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "4";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "12";
            myDataRowC["40H"] = "7";
            myDataRowC["50H"] = "5";
            myDataRowC["60H"] = "4";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "25";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "4";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "0";
            myDataRowC["30H"] = "17";
            myDataRowC["40H"] = "9";
            myDataRowC["50H"] = "7";
            myDataRowC["60H"] = "6";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "2";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "20";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "7";
            myDataRowC["30H"] = "3";
            myDataRowC["40H"] = "2";
            myDataRowC["50H"] = "2";
            myDataRowC["60H"] = "1";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "0.5";
            myDataRowC["90H"] = "0.5";
            myDataRowC["Temp"] = "35";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "13";
            myDataRowC["30H"] = "5";
            myDataRowC["40H"] = "3";
            myDataRowC["50H"] = "2";
            myDataRowC["60H"] = "2";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "30";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "18";
            myDataRowC["30H"] = "6";
            myDataRowC["40H"] = "4";
            myDataRowC["50H"] = "3";
            myDataRowC["60H"] = "3";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "25";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "0";
            myDataRowC["20H"] = "26";
            myDataRowC["30H"] = "8";
            myDataRowC["40H"] = "6";
            myDataRowC["50H"] = "5";
            myDataRowC["60H"] = "4";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "2";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "20";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "7";
            myDataRowC["20H"] = "2";
            myDataRowC["30H"] = "1";
            myDataRowC["40H"] = "1";
            myDataRowC["50H"] = "1";
            myDataRowC["60H"] = "1";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "0.5";
            myDataRowC["90H"] = "0.5";
            myDataRowC["Temp"] = "35";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "10";
            myDataRowC["20H"] = "3";
            myDataRowC["30H"] = "2";
            myDataRowC["40H"] = "1";
            myDataRowC["50H"] = "1";
            myDataRowC["60H"] = "1";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "0.5";
            myDataRowC["Temp"] = "30";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "13";
            myDataRowC["20H"] = "5";
            myDataRowC["30H"] = "3";
            myDataRowC["40H"] = "2";
            myDataRowC["50H"] = "2";
            myDataRowC["60H"] = "2";
            myDataRowC["70H"] = "1";
            myDataRowC["80H"] = "1";
            myDataRowC["90H"] = "1";
            myDataRowC["Temp"] = "25";
            TableC.Rows.Add(myDataRowC);
            myDataRowC = TableC.NewRow();
            myDataRowC["MSL"] = "5a";
            myDataRowC["5H"] = "0";
            myDataRowC["10H"] = "18";
            myDataRowC["20H"] = "6";
            myDataRowC["30H"] = "4";
            myDataRowC["40H"] = "3";
            myDataRowC["50H"] = "2";
            myDataRowC["60H"] = "2";
            myDataRowC["70H"] = "2";
            myDataRowC["80H"] = "2";
            myDataRowC["90H"] = "2";
            myDataRowC["Temp"] = "20";
            TableC.Rows.Add(myDataRowC);
            dTA = TableA;
            dTB = TableB;
            dTC = TableC;
        }
    }
}
